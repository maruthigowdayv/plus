document.addEventListener('deviceready',DeviceReady,false);
document.addEventListener('pause',DevicePause,false);
document.addEventListener('resume',DeviceResume,false);

var splashScreenStatus=1;
function splashScreenCHK(){if(splashScreenStatus==1){navigator.splashscreen.show()}else{navigator.splashscreen.hide();clearInterval(splashScreenCHKInterval)}}

function DeviceReady(){
	var splashScreenCHKInterval=setInterval(function(){splashScreenCHK()},1)
	if(cordova.platformId=='android'){StatusBar.overlaysWebView(false);StatusBar.backgroundColorByHexString('#b71c1c');StatusBar.styleLightContent()}
}

function DevicePause(){
	//nothing
}

function DeviceResume(){
	//nothing
}

















// Initialise App
var myApp = new Framework7({
	material: true,
    modalTitle: 'JCP+'
});

// Expose Internal DOM library
var $$ = Dom7;

// Add main view
var mainView = myApp.addView('.view-main', {});

























 
//JCP+ App & Version
var jcp_plus_app=myApp.device.os;if(jcp_plus_app!='android'&&navigator.userAgent.indexOf("Chrome") != -1){jcp_plus_app='chrome'}
var jcp_plus_version="2.0.0";

//JCP+ Auth Variables
var jcp_plus_passcode = '';if(localStorage.getItem("jcp_plus_passcode")){jcp_plus_passcode = localStorage.getItem("jcp_plus_passcode");}
var passcodeNumpadInline = '';

Date.prototype.toIsoString=function(){this.getTimezoneOffset();var t=function(t){var e=Math.floor(Math.abs(t));return(e<10?"0":"")+e};return this.getFullYear()+"-"+t(this.getMonth()+1)+"-"+t(this.getDate())};












//POST API FUNCTION
function jcp_plus_http_post_api(sender, params, retry){

	retry = retry || 0;
	
	result = '';
	
	if(sender == 'silent' && retry == 0){ $$('.panel-overlay').show(); myApp.showProgressbar($$('body'),'red'); }
	else if( sender != 'silent' && sender != 'background' && retry == 0 ){ $$('.panel-overlay').show(); $$('.'+sender+' .submit').hide(); $$('.'+sender+' .progress').show(); }	
	
	$$.ajax({

		async: true,

		method: 'POST',

		contentType: 'application/x-www-form-urlencoded',

		url: 'https://www.maruthigowda.com/JCP+/api',

		data: params,

		timeout: 20000,

		success: function(data, status, xhr){

			//console.log("Response: SUCCESS\n\nStatus: " + status + "\n\nData: " + JSON.stringify(data) + "\n\n" + "XHR: " + JSON.stringify(xhr))
			
			retry = retry + 1;
			
			try{data = JSON.parse(data)}catch(e){}
			
			if(!data){result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive any response from API server. Contact JCP+ support team to fix this issue.'};}
			
			else if(!data.todo){result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid TDA response from API server. Contact JCP+ support team to fix this issue.'};}
			
			else if(data.todo != 'retry' && data.todo != 'alert' && data.todo != 'next' && data.todo != 'goto' && data.todo != 'alert_next' && data.todo != 'alert_goto'){result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid CMD response from API server. Contact JCP+ support team to fix this issue.'};}
			
			else if(data.todo=='retry'){
				if( retry < 10 ){
					result = {todo: 'retry'};
				} else {
					result = {todo: 'alert', title: 'Sorry!', message: 'We did our best to reach API server but we couldn\'t succeed. Please fix your internet connectivity and retry.'};
				}
			}
					
			else if(data.todo.indexOf('alert')!=-1){
					if(!data.title||!data.message){
						result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid ALT response from API server. Contact JCP+ support team to fix this issue.'};
					} else {
							if(data.todo.indexOf('next')!=-1){
								if(!data.next){
									result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid ALTNXT response from API server. Contact JCP+ support team to fix this issue.'};
								} else {
									result = {todo: 'alert_next', title: data.title, message: data.message, next: data.next, arguments: data.arguments};
								}
							}
							
							else if(data.todo.indexOf('goto')!=-1){
								if(!data.goto){
									result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid ALTGTP response from API server. Contact JCP+ support team to fix this issue.'};
								} else {
									result = {todo: 'alert_goto', title: data.title, message: data.message, goto: data.goto};
								}
							}
					}
			}

			else if(data.todo=='next'){
				if(!data.next){
					result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid NXT response from API server. Contact JCP+ support team to fix this issue.'};
				} else {
					result = {todo: 'next', next: data.next, arguments: data.arguments};
				}
			}
			
			else if(data.todo=='goto'){
					if(!data.goto){
						result = {todo: 'alert', title: 'Sorry!', message: 'We did not receive valid GTP response from API server. Contact JCP+ support team to fix this issue.'};
					} else {
						result = {todo: 'goto', goto: data.goto};
					}
			}
			
			jcp_plus_http_post_api_callback(sender, params, retry, result);
		
		},
		
		error: function(xhr, status){
			
			//console.log("Response: ERROR\n\nStatus: "+ status + '\n\nXHR: ' + JSON.stringify(xhr))
						
			retry = retry + 1;
			
			if( retry < 10 ){
				result = {todo: 'retry'};
			} else {
				result = {todo: 'alert', title: 'Sorry!', message: 'We did our best to reach API server but we couldn\'t succeed. Please fix your internet connectivity and retry.'};
			}

			jcp_plus_http_post_api_callback(sender, params, retry, result);

		}
		
	});

}














function jcp_plus_http_post_api_callback(sender, params, retry, result){
	setTimeout(function(){
	if(sender == 'silent' && result.todo != 'retry'){myApp.hideProgressbar(); $$('.panel-overlay').hide()}
	else if(sender != 'silent' && sender != 'background'){if(result.todo=='retry'){$$('#'+sender+' .progress .indicator').text('Retrying (' + result.retry + ')');}else{$$('.'+sender+' .progress').hide(); $$('.'+sender+' .submit').show(); $$('.panel-overlay').hide()}}

	if(result.todo=='alert'){if(sender != 'background'){myApp.alert(result.message, result.title,function(){jcp_plus_http_post_api_callback_helper()})}}
	else if(result.todo=='alert_next'){myApp.alert(result.message,result.title,function (){window[result.next](result.arguments)})}
	else if(result.todo=='alert_goto'){myApp.alert(result.message,result.title,function (){mainView.router.loadPage(result.goto)})}
	else if(result.todo=='next'){window[result.next](result.arguments)}
	else if(result.todo=='goto'){mainView.router.loadPage(result.goto)}
	else if(result.todo=='retry'){jcp_plus_http_post_api(sender, params, retry)}
	},1000)
}


function jcp_plus_http_post_api_callback_helper(){
	if(mainView.activePage.name=='passcode'){jcp_plus_login_passcode_failed();}
}

















//FORM INPUT FOCUS
$$(document).on("click", ".picker-keypad-button-dark.passcode",function(){
	mainView.router.loadPage('html/passcode-self-help.html')
});

//FORM INPUT FOCUS
$$(document).on("click", "form .item-content", function() {
	$$(this).find(".item-input-field input").focus();
});

//CREATE PASSCODE FORM VALIDATION
$$(document).on("click", ".html-page-passocde-self-help-create form .submit", function() {
var input_email = $$("#passcode_email").val().trim().toLowerCase();
var input_phone = $$("#passcode_phone").val().trim();
if(input_email==""){myApp.alert('Please enter your email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_email.substr(input_email.length - 8)!="@jcp.com"){myApp.alert('Please enter your xxxx@jcp.com email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_email=="xxx@jcp.com"){myApp.alert('Please enter a valid email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_phone==""){myApp.alert('Please enter your phone number.', 'Yo!',function(){$$("#passcode_phone").focus()});return false;}
if(input_phone.length<10){myApp.alert('Please enter a valid phone number.', 'Yo!',function(){$$("#passcode_phone").focus()});return false;}
jcp_plus_http_post_api('html-page-passocde-self-help-create', {todo: 'create_passcode', email: input_email, phone: input_phone})
});

//RECOVER PASSCODE FORM VALIDATION
$$(document).on("click", ".html-page-passocde-self-help-recover form .submit",function(){
var input_email = $$("#passcode_email").val().trim().toLowerCase();
var input_phone = $$("#passcode_phone").val().trim();
if(input_email==""){myApp.alert('Please enter your registered email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_email.substr(input_email.length - 8)!="@jcp.com"){myApp.alert('Please enter your xxxx@jcp.com registered email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_email=="xxx@jcp.com"){myApp.alert('Please enter a valid registered email address.', 'Yo!',function(){$$("#passcode_email").focus()});return false;}
if(input_phone==""){myApp.alert('Please enter your registered phone number.', 'Yo!',function(){$$("#passcode_phone").focus()});return false;}
if(input_phone.length<10){myApp.alert('Please enter a valid registered phone number.', 'Yo!',function(){$$("#passcode_phone").focus()});return false;}
jcp_plus_http_post_api('html-page-passocde-self-help-recover', {device: jcp_plus_app, version: jcp_plus_version, todo: 'recover_passcode', email: input_email, phone: input_phone})
});

// PASSCODE AUTH API
function jcp_plus_auth_chk(){
	if(jcp_plus_app=='chrome'){$$('body').addClass('chrome')}
	if(!localStorage.getItem("jcp_plus_passcode")){
		mainView.router.loadPage({url: 'html/passcode.html', animatePages: false});
	} else {
		if(localStorage.getItem("jcp_plus_passcode").split('@')[1].split(' ')[0] != new Date().toIsoString() ){
			mainView.router.loadPage({url: 'html/passcode.html', animatePages: false});
		} else {
			welcome_warrior();	
		}		
	}
};

jcp_plus_auth_chk();

function jcp_plus_login_passcode_failed(){
	mainView.router.loadPage({url: 'html/passcode.html'});
	passcodeNumpadInline.value = '';$$("#passcode_input").val('______');
}

function jcp_plus_login_passcode_success(arguments){
	localStorage.setItem("jcp_plus_passcode", arguments.jcp_plus_passcode);jcp_plus_passcode = arguments.jcp_plus_passcode;
	localStorage.setItem("jcp_plus_warrior", arguments.jcp_plus_warrior);
	localStorage.setItem("jcp_plus_settings", arguments.jcp_plus_settings);
	localStorage.setItem("jcp_plus_dashboard_filters_and_views_product_enrichment", arguments.jcp_plus_dashboard_filters_and_views.product_enrichment);
	localStorage.setItem("jcp_plus_dashboard_filters_and_views_image_enrichment", arguments.jcp_plus_dashboard_filters_and_views.image_enrichment);
	localStorage.setItem("jcp_plus_dashboard_filters_and_views_plano_assistance", arguments.jcp_plus_dashboard_filters_and_views.plano_assistance);
	if(arguments.jcp_plus_site_audit_assistant_settings){localStorage.setItem("jcp_plus_site_audit_assistant_settings", arguments.jcp_plus_site_audit_assistant_settings);}	
	$$('.panel-overlay').hide();
	welcome_warrior();
}

function welcome_warrior(){
	if(!localStorage.getItem("jcp_plus_warrior")){myApp.alert('JCP+ couldn\'t save data on your device. Please free up some space and retry.', 'Sorry!');return false}
	warrior_info = localStorage.getItem("jcp_plus_warrior").split('~');
	$$('.html-page-panel-left .item-media img').attr('src','https://www.maruthigowda.com/JCP+/file/user/'+warrior_info[0].toLowerCase().replace(/ /g,'-')+'.jpg');
	$$('.html-page-panel-left .item-title-row .item-title').text(warrior_info[0]);
	$$('.html-page-panel-left .item-subtitle').text(warrior_info[5]);
	mainView.router.loadPage({url: 'html/welcome.html', animatePages: false});
	setTimeout(function(){for(var i = 0; i < mainView.history.length;i++){if(mainView.history[i]==='html/passcode.html'){mainView.history.splice(i,1);$$('.view-main .html-page-passcode').remove();}}},1000)
	splashScreenStatus = 0;
}

function jcp_plus_update_app(){
	window.open('https://www.maruthigowda.com/JCP+/update', '_blank');
}

/* ===== On Page Load Callbacks  ===== */
myApp.onPageInit('passcode', function (page){
	for(var i = 0; i < mainView.history.length;i++){if(mainView.history[i]==='html/welcome.html'){mainView.history.splice(i,1);$$('.view-main .html-page-welcome').remove();}}
	localStorage.removeItem("jcp_plus_passcode");
	passcodeNumpadInline = myApp.keypad({
		input: '#passcode_input',
		container: '#numpad-inline-container',
		toolbar: false,
		valueMaxLength: 6,
		dotButton: false,
		formatValue: function(p, value) {value = value.toString();return ('********').substring(0, value.length) + ('______').substring(0, 6 - value.length);},
		onChange: function (p, value){value = value.toString();if (value.length === 6){
			$$('.panel-overlay').show();
			jcp_plus_http_post_api('silent', {device: jcp_plus_app, version: jcp_plus_version, todo: 'login_passcode', passcode: value});
		}}
	});
	splashScreenStatus = 0;
	$$(".picker-keypad-button-dark").removeClass("disabled");
})

$$(window).keydown(function(e){
	key_code = event.keyCode;

	if( jcp_plus_app!='chrome' || mainView.activePage.name!='passcode' ){return false}

	if(key_code==8 && $$('.html-page-passcode #passcode_input').val() != '______' ){
		$$('#numpad-inline-container .picker-keypad-delete').click();
	}

	else if ( ( (key_code >= 48 && key_code <= 57) || (key_code >= 96 && key_code <= 105) ) && $$('.html-page-passcode #passcode_input').val() != '******' ) {
		key_name = '';
		if(key_code==48||key_code==96){key_name='0'}
		else if(key_code==49||key_code==97){key_name='1'}
		else if(key_code==50||key_code==98){key_name='2'}
		else if(key_code==51||key_code==99){key_name='3'}
		else if(key_code==52||key_code==100){key_name='4'}
		else if(key_code==53||key_code==101){key_name='5'}
		else if(key_code==54||key_code==102){key_name='6'}
		else if(key_code==55||key_code==103){key_name='7'}
		else if(key_code==56||key_code==104){key_name='8'}
		else if(key_code==57||key_code==105){key_name='9'}
		$$('#numpad-inline-container .picker-keypad-button-number').filter(function(){return $$(this).text() === key_name}).click();
	}
})

var mySwiper;
myApp.onPageBeforeInit('welcome', function (page){
	
	dashboard_primary = localStorage.getItem("jcp_plus_warrior").split('~')[4].split(' > ')[2].toLowerCase().replace(/ /g, '_');
	swiperSlide = 0;
	if(dashboard_primary=='product_enrichment'){swiperSlide=0;}
	else if(dashboard_primary=='image_enrichment'){swiperSlide=1;}
	else if(dashboard_primary=='plano_assistance'){swiperSlide=2;}

	mySwiper = myApp.swiper('.swiper-container', {
		initialSlide: swiperSlide,
		autoHeight: true,
		speed: 300,
		spaceBetween: 100,
		noSwiping: true,
		noSwipingClass: 'amcharts-export-canvas',
		onInit: function(mySwiper){makeDashboard(dashboard_primary, mySwiper)},
		onSlideChangeEnd: function(mySwiper){
		if($$('.swiper-slide-active').hasClass('product-enrichment-dashboard')){if($$('.product-enrichment-dashboard .filter1').text()==='. . .'){makeDashboard('product_enrichment', mySwiper)}}
		else if($$('.swiper-slide-active').hasClass('image-enrichment-dashboard')){if($$('.image-enrichment-dashboard .filter1').text()==='. . .'){makeDashboard('image_enrichment', mySwiper)}}
		else if($$('.swiper-slide-active').hasClass('plano-assistance-dashboard')){if($$('.plano-assistance-dashboard .filter1').text()==='. . .'){makeDashboard('plano_assistance', mySwiper)}}
		}
	});
	
})

myApp.onPageInit('welcome', function (page){	
	//???
})


/* ===== Change statusbar bg when panel opened/closed ===== */
$$('.panel-left').on('open', function () {
    $$('.statusbar-overlay').addClass('with-panel-left');
});

/* ===== Generate Content Dynamically ===== */
$$(document).on('click', '.html-page-panel-left .generate-dynamic-page-for-warrior-profile', function generateDynamicPageForWarriorProfile(){
	warrior_info = localStorage.getItem("jcp_plus_warrior").split('~')
	mainView.router.loadContent(
		'<div data-page="dynamic-warrior-profile" class="page html-dynamic-page-warrior-profile">' +
		'  <div class="navbar">' +
		'    <div class="navbar-inner">' +
		'      <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
		'      <div class="center">Warrior Profile</div>' +
		'    </div>' +
		'  </div>' +
		'  <div class="page-content">' +
		'	<div class="list-block media-list warrior-bio">' +
		'      <ul>' +
		'        <li>' +
		'          <div class="item-content">' +
		'            <div class="item-media"><img src="https://www.maruthigowda.com/JCP+/file/user/'+warrior_info[0].toLowerCase().replace(/ /g,'-')+'.jpg" width="44"></div>' +
		'            <div class="item-inner">' +
		'              <div class="item-title-row">' +
		'                <div class="item-title">'+warrior_info[0]+'</div>' +
		'              </div>' +
		'              <div class="item-subtitle">'+warrior_info[5]+'</div>' +
		'            </div>' +
		'          </div>' +
		'        </li>' +
		'      </ul>' +
		'    </div>' +

		'    <div class="list-block">' +
		'      <ul>' +
		'        <li><a href="#" data-alert="My team is<br><strong>'+warrior_info[4].replace(/>/g,"<br><i class='material-icons' style='float:left;color:#757575;margin-left: -3px;'>subdirectory_arrow_right</i> ")+'</strong>" class="item-link item-content">' +
		'            <div class="item-media"><i class="material-icons">group</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[4].replace(/>/g, ' » ')+'</div>' +
		'            </div></a></li>' +
		'        <li><a href="#" data-alert="My workstation is<br><strong>'+warrior_info[6]+'</strong>" class="item-link item-content">' +
		'            <div class="item-media"><i class="material-icons">location_city</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[6]+'</div>' +
		'            </div></a></li>' +
		'			<li><a href="#" data-alert="My email is<br><strong>'+warrior_info[1]+'</strong>" class="item-link item-content external">' +
		'            <div class="item-media"><i class="material-icons">send</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[1]+'</div>' +
		'              <div class="item-after"></div>' +
		'            </div></a></li>' +
		'        <li><a href="#" data-alert="My phone number is<br><strong>'+warrior_info[2]+'</strong>" class="item-link item-content external">' +
		'            <div class="item-media"><i class="material-icons">perm_phone_msg</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[2]+'</div>' +
		'              <div class="item-after"></div>' +
		'            </div></a></li>' +
		'        <li><a href="#" data-alert="My access level is<br><strong>'+warrior_info[9]+'</strong>" class="item-link item-content">' +
		'            <div class="item-media"><i class="material-icons">flash_on</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[9]+'</div><div class="item-after"></div>' +
		'            </div></a></li>' +
		'        <li><a href="#" data-alert="Modules I have access to<br><strong>' + "<i class='material-icons' style='float:left;color:#757575;margin-left: -7px;'>keyboard_arrow_right</i>" +warrior_info[10].replace(/\|/g,"<br><i class='material-icons' style='float:left;color:#757575;margin-left: -7px;'>keyboard_arrow_right</i> ")+'</strong>" class="item-link item-content">' +
		'            <div class="item-media"><i class="material-icons">transfer_within_a_station</i></div>' +
		'            <div class="item-inner"> ' +
		'              <div class="item-title">'+warrior_info[10].replace(/\|/g, ', ')+'</div><div class="item-after"></div>' +
		'            </div></a></li>' +
		'      </ul>' +
		'    </div>' +

		'	<div class="list-block media-list about-me">' +
		'      <ul>' +
		'        <li>' +
		'          <div class="item-content">' +
		'            <div class="item-inner">' +
		'              <div class="item-title">About Me</div>' +
		'				'+warrior_info[7]+
		'			</div>' +
		'          </div>' +
		'        </li>' +
		'      </ul>' +
		'      <ul class="no-border-bottom">' +
		'        <li>' +
		'          <div class="item-content">' +
		'            <div class="item-inner">' +
		'              <div class="item-title">My Golden Rule</div>' +
		'				'+warrior_info[8]+
		'			</div>' +
		'          </div>' +
		'        </li>' +
		'      </ul>' +
		'    </div>	' +
		'</div>' +
		'</div>'
    );
    return;
})

$$(document).on('click', '.html-dynamic-page-warrior-profile li a', function showWarriorProfileItem(){
	myApp.alert($$(this).attr('data-alert'), '')
})

$$(document).on('click', '.generate-page-for-jcp-plus-mission', function generateDynamicPageForJcpPlusMission(){
    mainView.router.loadContent(
        '  <div data-page="dynamic-jcp-plus-mission" class="page html-dynamic-page-jcp-plus-mission">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="html/jcp-plus-mission.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Watching Video</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
        '      <div class="content-block">' +
        '        <video poster="https://www.maruthigowda.com/JCP+/file/jcp-plus-mission/'+$$(this).attr('data-video-file').replace('.mp4','.png')+'" autoplay><source src="https://www.maruthigowda.com/JCP+/file/jcp-plus-mission/'+$$(this).attr('data-video-file')+'" type="video/mp4"></video>' +
        '      </div>' +
        '    </div>' +
        '  </div>'
    );
    return;
})

$$(document).on('click', '.generate-dynamic-page-for-notifications', function(){
	generateDynamicPageForNotifications();
})

function generateDynamicPageForNotifications(){

	zero_notifications_class = '';
	notifications_array_html = '';

	if( !localStorage.getItem("jcp_plus_notifications") || localStorage.getItem("jcp_plus_notifications").length==0 || (localStorage.getItem("jcp_plus_notifications").indexOf('0~')==-1&&localStorage.getItem("jcp_plus_notifications").indexOf('1~')==-1&&localStorage.getItem("jcp_plus_notifications").indexOf('3~')==-1) ){

		zero_notifications_class='zero-notifications';

	} else {

		notification_info_array = localStorage.getItem("jcp_plus_notifications");notification_info_array = notification_info_array.substring(0, notification_info_array.length - 1).split('~');
		
		$$.each(notification_info_array, function(i, item) {
			
			notification_info = item.split('|');
			
			month_array = new Array(); month_array[0] = "Jan"; month_array[1] = "Feb"; month_array[2] = "Mar"; month_array[3] = "Apr"; month_array[4] = "May"; month_array[5] = "Jun"; month_array[6] = "Jul"; month_array[7] = "Aug"; month_array[8] = "Sep"; month_array[9] = "Oct"; month_array[10] = "Nov"; month_array[11] = "Dec";

			notification_datetime = new Date((notification_info[1]));
			
			notification_datetime = month_array[notification_datetime.getMonth()] + ' ' + notification_datetime.getDay() + ', ' + notification_info[1].split(' ')[1].split(':')[0] + ':' + notification_datetime.getMinutes() + ' ' + notification_info[1].split(' ')[2];

			notification_freshness_html='';if(notification_info[5]==0){notification_freshness_html = '<span class="badge bg-green">new</span>';}

			if(notification_info[5]!=2){notifications_array_html +='<li class="swipeout" data-notification-index="'+i+'" data-notification-id="'+notification_info[0]+'" data-notification-message="'+notification_info[4]+'"> <div class="swipeout-content"><a href="#" class="item-link item-content"> <div class="item-media"><img src="https://www.maruthigowda.com/JCP+/file/user/'+(notification_info[2]).toLowerCase().replace(/ /g,'-')+'.jpg" width="44"></div> <div class="item-inner"> <div class="item-title-row"> <div class="item-title">'+notification_info[2]+'<i class="material-icons">arrow_forward</i>'+notification_datetime+'</div> <div class="item-after">'+notification_freshness_html+'</div> </div> <div class="item-subtitle">'+notification_info[3]+'</div></div></a></div> <div class="swipeout-actions-right"><a href="#" class="bg-red swipeout-overswipe notification-delete">Delete</a></div> </li>';}
			
		});

	}

	notifications_final_html = '' +
		'	<div data-page="dynamic-notifications" class="page html-dynamic-page-notifications">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Notifications</div>' +
		'		 <div class="right"><a href="#" class="link icon-only generate-dynamic-page-for-notification-settings"><i class="material-icons">notifications_active</i></a></div>'+
        '      </div>' +
        '    </div>' +
        '    <div class="page-content '+zero_notifications_class+'">' +
        '    <div class="list-block media-list">' +
        '    <ul>' + notifications_array_html +
        '    </ul>' +
        '    </div>' +
        '    </div>' +
        '  </div>';

	if(mainView.activePage.name=='dynamic-notifications'){mainView.router.reloadContent(notifications_final_html);}else{mainView.router.loadContent(notifications_final_html);}

}

$$(document).on('click', '.html-dynamic-page-notifications .swipeout', function generateDynamicPageForNotificationDetail(){
	if($$(this).hasClass('swipeout-opened')){return false}
	
	item_to_be_opened_id = $$(this).attr('data-notification-id');
	
	notification_info_array = localStorage.getItem("jcp_plus_notifications");notification_info_array = notification_info_array.substring(0, notification_info_array.length - 1).split('~');
	notification_info = '';
	
	notification_info_array_new = '';
	$$.each(notification_info_array, function(i, item) {
		item = item.split('|');
		if(item[5]==0&&item[5]!=3){notification_info_array_new += item[0]+'|'+item[1]+'|'+item[2]+'|'+item[3]+'|'+item[4]+'|1~';}else{notification_info_array_new += notification_info_array[i] + '~';}
		if(item[0]==item_to_be_opened_id && notification_info==''){
			notification_info = notification_info_array[i];
		}
	})
	
	localStorage.setItem("jcp_plus_notifications", notification_info_array_new);
	$$(this).find('.item-after').remove();
	
	notification_info = notification_info.split('|');

	month_array = new Array(); month_array[0] = "Jan"; month_array[1] = "Feb"; month_array[2] = "Mar"; month_array[3] = "Apr"; month_array[4] = "May"; month_array[5] = "Jun"; month_array[6] = "Jul"; month_array[7] = "Aug"; month_array[8] = "Sep"; month_array[9] = "Oct"; month_array[10] = "Nov"; month_array[11] = "Dec";

	notification_datetime = new Date((notification_info[1]));notification_datetime = month_array[notification_datetime.getMonth()] + ' ' + notification_datetime.getDay() + ', ' + notification_info[1].split(' ')[1].split(':')[0] + ':' + notification_datetime.getMinutes() + ' ' + notification_info[1].split(' ')[2];

    mainView.router.loadContent(
        '  <div data-page="dynamic-notification-details" class="page html-dynamic-page-notification-details">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Notification Details</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
        '        <div class="list-block media-list"> <ul> <li> <div class="item-content"> <div class="item-media"><img src="https://www.maruthigowda.com/JCP+/file/user/'+notification_info[2].toLowerCase().replace(/ /g,'-')+'.jpg" width="44"></div> <div class="item-inner"> <div class="item-title-row"> <div class="item-title">'+notification_info[2]+'</div> </div> <div class="item-subtitle">'+notification_datetime+'</div> </div> </div> </li> </ul> </div>' +
        '        <div class="list-block media-list"> <ul> <li> <div class="item-content"><div class="item-inner"><div class="item-title-row"> <div class="item-title">'+notification_info[3]+'</div> </div> <p>'+notification_info[4]+'</p> </div> </div> </li> </ul> </div>' +
        '    </div>' +
        '  </div>'
    );

	jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'read_notification', id: notification_info[0]});
	
})

myApp.onPageInit('dynamic-notifications', function (page) {
    $$('.notification-delete').on('click', function () {
		item_to_be_removed = $$(this).parents('.swipeout');
		item_to_be_removed_id = $$(this).parents('.swipeout').attr('data-notification-id');
		
		myApp.confirm('Are you sure to delete this notification?', 'Confirmation', function () {
			item_to_be_removed.remove();
			notification_info_array = localStorage.getItem("jcp_plus_notifications");notification_info_array = notification_info_array.substring(0, notification_info_array.length - 1).split('~');
			
			notification_info_array_new = '';
			$$.each(notification_info_array, function(i, item){
				if(item.split('|')[0]!=item_to_be_removed_id){
					notification_info_array_new += notification_info_array[i] + '~';
				}
			})
			
			if(notification_info_array_new==''){localStorage.removeItem("jcp_plus_notifications")}else{localStorage.setItem("jcp_plus_notifications", notification_info_array_new)}

			if(localStorage.getItem("jcp_plus_notifications")){if(localStorage.getItem("jcp_plus_notifications").indexOf('0~')==-1&&localStorage.getItem("jcp_plus_notifications").indexOf('1~')==-1&&localStorage.getItem("jcp_plus_notifications").indexOf('3~')==-1){$$('.html-dynamic-page-notifications .page-content').addClass('zero-notifications')}}else{$$('.html-dynamic-page-notifications .page-content').addClass('zero-notifications')}

			jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'delete_notification', id: item_to_be_removed_id});

		});
    });
});

$$(document).on('click', '.generate-dynamic-page-for-settings', function generateDynamicPageForSettings(){
	settingInfo = localStorage.getItem("jcp_plus_settings").split('|');
	settings_1 = 'false';if(settingInfo[0]==1){settings_1='checked'}
	settings_2 = 'false';if(settingInfo[1]==1){settings_2='checked'}
	settings_3 = 'false';if(settingInfo[2]==1){settings_3='checked'}
	
    mainView.router.loadContent(
        '  <div data-page="dynamic-settings" class="page html-dynamic-page-settings">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Settings</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
        '    <div class="content-block-title">Control how JCP+ works for you.</div>' +		
		'   <div class="list-block">'+ 
		' 	<ul>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'         <div class="item-title">Push Notifications</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="push_notifications" '+settings_1+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'         <div class="item-title">Whatsapp Integration</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="whatsapp_integration" '+settings_2+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'         <div class="item-title">Voice Assistant</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="voice_assistant" '+settings_3+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'   </ul>'+
		'   </div>'+
        '    </div>' +
        '  </div>'
    );
    return;
})

setInterval(function(){backgroundGetNotifications()},60000);

function backgroundGetNotifications(){
	if(localStorage.getItem("jcp_plus_passcode")){
		if(localStorage.getItem("jcp_plus_passcode").split('@')[1].split(' ')[0] != new Date().toIsoString() ){
			mainView.router.loadPage({url: 'html/passcode.html', animatePages: false});
		} else {

			notifications_to_mark_as_opened = '';notifications_to_mark_as_deleted = '';
			
			if(localStorage.getItem("jcp_plus_notifications")){
				notification_info_array = localStorage.getItem("jcp_plus_notifications");notification_info_array = notification_info_array.substring(0, notification_info_array.length - 1).split('~');
								
				$$.each(notification_info_array, function(i, item){
					item = item.split('|');
					if(item[5]==1){notifications_to_mark_as_opened += item[0] + ','}
					else if(item[5]==2){notifications_to_mark_as_deleted += item[0] + ','}
				})

				notifications_to_mark_as_opened = notifications_to_mark_as_opened.substring(0, notifications_to_mark_as_opened.length-1);
				notifications_to_mark_as_deleted = notifications_to_mark_as_deleted.substring(0, notifications_to_mark_as_deleted.length-1);
			}
			
			jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'sync_notifications', notifications: notifications_to_mark_as_opened +'|'+ notifications_to_mark_as_deleted});					
						
			if(mainView.activePage.name=='welcome'){
				which_dashboard = $$('div[data-page="welcome"] .swiper-slide-active .filter2').text().toLowerCase().replace(/ /g, '_');
				if( $$("."+which_dashboard.replace(/_/g, '-')+"-dashboard .filter1").text() == 'Today'){makeDashboard_Step_2(which_dashboard);}
			}
			
		}
	}
}

function sync_notifications_success(arguments){
	
	notification_info_array_new = '';
	
	if(localStorage.getItem("jcp_plus_notifications")){
		notification_info_array = localStorage.getItem("jcp_plus_notifications");notification_info_array = notification_info_array.substring(0, notification_info_array.length - 1).split('~');
		$$.each(notification_info_array, function(i, item){
			item = item.split('|');
			if(item[5]!=2){
				if(item[5]==1){
					notification_info_array_new += item[0]+'|'+item[1]+'|'+item[2]+'|'+item[3]+'|'+item[4]+'|3~';
				} else {
					notification_info_array_new += notification_info_array[i] + '~';
				}
			}
		})
	}
	
	//console.log('AAA: '+arguments+'\nBBB: '+notification_info_array_new)

	if( arguments==''){
		if(notification_info_array_new==''){localStorage.removeItem("jcp_plus_notifications")}else{localStorage.setItem("jcp_plus_notifications", notification_info_array_new)}
		return false;
	}
		
	arguments_notification_info_array = arguments;arguments_notification_info_array = arguments_notification_info_array.substring(0, arguments_notification_info_array.length - 1).split('~');
	number_of_new_notifications = 0
	$$.each(arguments_notification_info_array, function(i, item){
		
		console.log(( '~' + notification_info_array_new ).indexOf('~'+item.split('|')[0]+'|') == -1)
		
		if( ( '~' + notification_info_array_new ).indexOf('~'+item.split('|')[0]+'|')==-1){
			number_of_new_notifications += 1;
			notification_info_array_new += arguments_notification_info_array[i] + '~';
		}
	})

	if(number_of_new_notifications==0){return false}
	
	if(number_of_new_notifications==1){
		notification_info_parts = arguments_notification_info_array[0].split('|');
		chrome_notification_icon_url = 'https://www.maruthigowda.com/JCP+/file/user/'+notification_info_parts[2].toLowerCase().replace(/ /g, '-')+'.jpg';
		chrome_notification_title = notification_info_parts[2];
		chrome_notification_message = notification_info_parts[3];
	} else {
		chrome_notification_icon_url = 'https://www.maruthigowda.com/JCP+/file/user/JCP+.jpg';
		chrome_notification_title = 'JCP+';
		chrome_notification_message = 'You have multiple unread notifications.';
	}

	localStorage.setItem("jcp_plus_notifications", notification_info_array_new);

	chrome.notifications.create("jcp_plus_chrome_notification_id",{type:"basic",iconUrl:chrome_notification_icon_url,title:chrome_notification_title,message:chrome_notification_message,requireInteraction:true,buttons:[{title:"Yes, get me there",iconUrl: "chrome/icons/icon_128.png"},{title:"Get out of my way",iconUrl:"chrome/icons/icon_128.png"}]})

}













$$(document).on("change", ".html-dynamic-page-settings .label-switch input[type='checkbox']",function(){

	var settingInfo = (localStorage.getItem("jcp_plus_settings")).split('|');
	var settings_1 = settingInfo[0];
	var settings_2 = settingInfo[1];
	var settings_3 = settingInfo[2];
	
	var settings_checked = '';
	if($$(this).prop("checked")==true){settings_checked='1'}else{settings_checked='0'}
	
	if($$(this).attr("class")=='push_notifications'){settings_1=settings_checked}
	else if($$(this).attr("class")=='whatsapp_integration'){settings_2=settings_checked}
	else if($$(this).attr("class")=='voice_assistant'){settings_3=settings_checked}
	
	localStorage.setItem("jcp_plus_settings", settings_1+'|'+settings_2+'|'+settings_3)
	
	jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'update_settings', jcp_plus_settings: localStorage.getItem("jcp_plus_settings")});
});

function do_nothing(){/* nothing */}


/* ===== Messages Page ===== */
myApp.onPageInit('shoutbox', function (page) {
    var conversationStarted = false;
    var answers = [
        'Yes!',
        'No',
        'Hm...',
        'I am not sure',
        'And what about you?',
        'May be ;)',
        'Lorem ipsum dolor sit amet, consectetur',
        'What?',
        'Are you sure?',
        'Of course',
        'Need to think about it',
        'Amazing!!!',
    ];
    var people = [
        {
            name: 'JCP+ AI Bot',
            avatar: 'https://www.maruthigowda.com/JCP+/file/shoutbox/ai-bot.png'
        },

    ];
    var isFocused;
		
    // Initialize Messagebar
	var myMessagebar = myApp.messagebar('.messagebar');

    $$('.messagebar a.send-message').on('touchstart mousedown', function () {
        isFocused = document.activeElement && document.activeElement === myMessagebar.textarea[0];
    });
	
    $$('.messagebar a.send-message').on('click', function (e) {
        // Keep focused messagebar's textarea if it was in focus before
        if (isFocused) {
            e.preventDefault();
            myMessagebar.textarea[0].focus();
        }
        var messageText = myMessagebar.value();
        if (messageText.length === 0) {
            return;
        }
        // Clear messagebar
        myMessagebar.clear();
		
		// Initialize Messages
		var myMessages = myApp.messages('.messages');


        // Add Message
        myMessages.addMessage({
            text: messageText,
            avatar: 'https://www.maruthigowda.com/JCP+/file/user/'+localStorage.getItem('jcp_plus_warrior').split('~')[0].toLowerCase().replace(/ /g,'-')+'.jpg',
            type: 'sent',
            date: 'Now'
        });
        conversationStarted = true;
        // Add answer after timeout
			var answerText = answers[Math.floor(Math.random() * answers.length)];
			$$.ajax({
				url: 'https://www.cleverbot.com/getreply',
				data: {"input": messageText, "key": 'CC4ihBhmZ0Lpahc0quTCqjxAQEQ'}, //input automatically encoded
				dataType: "jsonp",
				success: function(data, status, xhr){
					var person = people[Math.floor(Math.random() * people.length)];
					myMessages.addMessage({
						text: JSON.parse(data).output,
						type: 'received',
						name: person.name,
						avatar: person.avatar,
						date: 'Just now'
					});
					answerText = data.output
				}
			});
    });
});

















//Fix android ripple wave
$$(document).on('click','a', function () {
//define link
var link = $$(this);

//put link in timetout context, we need wait 1400 ms until animation finish then we can start animation to hide ripple effect
setTimeout(
	function (link_a) {
		return function () {
			link_a.find(".ripple-wave").each(function (index, ripple) {
				$$(ripple).css('opacity', 0);
				setTimeout(function (ripple) {
					return function () {
						$$(ripple).remove();
					}
				}(ripple), 1400);
			})
		}
	}(link), 1400);
});



document.addEventListener("backbutton", onBackKeyDown, false); 
function onBackKeyDown() { 
	if($$('.panel-left').hasClass( "active" )){myApp.closePanel();return false;}
	else if(mainView.activePage.name=='passcode'||mainView.activePage.name=='welcome'){return false;}
	else{mainView.router.back();return true;}
}










$$(document).on('click', '.generate-dynamic-page-for-plus-modules', function generateDynamicPageForPlusModules(){
	
	var zero_plus_modules_class = ''; var plus_modules_array_html = '';
	
	if(localStorage.getItem("jcp_plus_warrior")&&localStorage.getItem("jcp_plus_warrior").access_modules!=''){

		var moduleInfo = localStorage.getItem("jcp_plus_warrior").split('~')[10].split('|')
		
		icon_site_audit_assistant = 'offline_pin';
		icon_defect_remediation_assistant = 'check_circle';
		icon_audit_and_remediation_report = 'stars';
		icon_scrubbing_assistant = 'broken_image';
		icon_zero_product_validator = 'explore';
		icon_pdq_assistant = 'donut_small';
		icon_pdq_scorecard = 'pie_chart';
		icon_knowledge_assistant = 'picture_as_pdf';
		icon_new_item_inspection_assistant = 'add_box';
		icon_new_item_inspection_scorecard = 'add_to_photos';
		icon_sephora_assistant = 'face';
		icon_sephora_scorecard = 'palette';
		icon_image_enrichment_assistant = 'image';
		icon_image_enrichment_scorecard = 'photo_library';
		icon_pricing_assistant = 'monetization_on';
		icon_pricing_scorecard = 'library_books';
		icon_time_machine = 'explore';
		icon_happiness_assistant = 'free_breakfast';
		
		$$.each(moduleInfo, function(i, item) {
			plus_modules_array_html +='<li><a href="#" class="item-link '+'plus_module_'+item.toLowerCase().replace(/ /g, '_')+'"><div class="item-content"><div class="item-media"><i class="material-icons">'+window['icon_'+item.toLowerCase().replace(/ /g, '_')]+'</i></div><div class="item-inner"><div class="item-title">'+item+'</div></div></div></a></li>';
		});
		
		plus_modules_array_html = plus_modules_array_html.replace('', '');
	
	} else {
		zero_plus_modules_class='zero-plus-modules'
	}
	
    mainView.router.loadContent(
        '  <div data-page="dynamic-plus-modules" class="page html-dynamic-page-plus-modules">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Plus Modules</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
        '    <div class="content-block-title">Work with ease and joy!</div>' +		
		'   <div class="list-block">'+ 
		' 	<ul>'+ plus_modules_array_html +
		'   </ul>'+
		'   </div>'+
        '    </div>'+
        '  </div>'
    );
    return;
})


$$(document).on('click', '.plus_module_site_audit_assistant', function plus_module_site_audit_assistant_clicked(){
	mainView.router.loadPage({url: 'html/site-audit-assistant.html'});
})

$$(document).on('click', '.plus_module_defect_remediation_assistant', function plus_module_defect_remediation_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_scrubbing_assistant', function plus_module_image_scrubbing_assistant(){
	    mainView.router.loadContent(
        '  <div data-page="image-scrubbing-assistant" class="page page-image-scrubbing-assistant">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only no-animation"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Scrubbing Assistant</div>' +
        '		 <div class="right"><a href="#" class="link icon-only assistant-control-button"><i class="material-icons">send</i></a></div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
		'	    <div class="content-block">'+
		'       <p>Enter PP or LOT numbers line by line and press "START" button.</p>' +
		'       <p><textarea></textarea></p>' +
		'	<div class="data-table">' +
		'	<table>' +
		'		<thead>' +
		'		<tr>' +
		'		<th>Input</th>' +
		'		<th>Status</th>' +
		'		<th>PP ID</th>' +
		'		<th>LOT IDs</th>' +
		'		<th>Missing Primary Image</th>' +
		'		<th>Missing Swatch Image</th>' +
		'		<th>CCR Issues</th>' +
		'		<th>Missing Brand Logo</th>' +
		'		<th>Missing KA</th>' +
		'		</tr>' +
		'		</thead>' +
		'		<tbody>' +
		'		</tbody>' +
		'	</table>' +
		'	</div>' +
		'	    </div>' +
        '    </div>' +
        '  </div>'
    );
})

$$(document).on('click', '.page-image-scrubbing-assistant .back', function plus_module_image_scrubbing_assistant_back(){
	$$("body").css("max-width", "564px");
})

$$(document).on('click', '.plus_module_audit_and_remediation_report', function plus_module_audit_and_remediation_report(){
	warrior_name = localStorage.getItem("jcp_plus_warrior").split('~')[0]
	date = new Date().toIsoString();
	
	donwload_team_report_html = '';
	if(warrior_name=='Maruthi Gowda'||warrior_name=='Nitesh S U'||warrior_name=='Vishal Kumar'||warrior_name=='Esha Sud'||warrior_name=='Reena Sofiya'||warrior_name=='Zeeshan'){
		donwload_team_report_html = '<p><button data-report-for="team" style="float:left;margin-left:20px;" class="button button-raised button-fill color-red download_audit_and_remediation_report">DOWNLOAD TEAM\'S REPORT</button></p>';
	}
	
    mainView.router.loadContent(
        '  <div data-page="defect-remediation-assistant" class="page page-defect-remediation-assistant">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Audit & Remediation Report</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
		'	    <div class="content-block">'+
		'       <p>Dear '+warrior_name+',<br><br>You can download your audit and remediation consolidated report here.<br><br></p>' +
		'       <p><button data-report-for="'+warrior_name+'" style="float:left;" class="button button-raised button-fill color-red download_audit_and_remediation_report">DOWNLOAD</button></p>' +
				donwload_team_report_html		+
		'	    </div>' +
        '    </div>' +
        '  </div>'
    );
})

$$(document).on('click', '.download_audit_and_remediation_report', function(){
	$$(this).addClass("disabled");
	window.location.href = 'https://www.maruthigowda.com/JCP+/reports/audit-and-remediation-report?person='+$$(this).attr('data-report-for');
});

$$(document).on('click', '.plus_module_pdq_assistant', function plus_module_pdq_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_pdq_scorecard', function plus_module_pdq_scorecard(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_new_item_inspection_assistant', function plus_module_new_item_inspection_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_new_item_inspection_scorecard', function plus_module_new_item_inspection_scorecard(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_sephora_assistant', function plus_module_sephora_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_sephora_scorecard', function plus_module_sephora_scorecard(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_image_enrichment_assistant', function plus_module_image_enrichment_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_image_enrichment_scorecard', function plus_module_image_enrichment_scorecard(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_pricing_assistant', function plus_module_pricing_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_pricing_scorecard', function plus_module_pricing_scorecard(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_time_machine', function plus_module_time_machine(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})

$$(document).on('click', '.plus_module_happiness_assistant', function plus_module_happiness_assistant(){
	myApp.alert('This module is currently work-in-progress. Please check back in sometime.', 'Sorry!');
})




$$(document).on('click', '.html-page-welcome .product-enrichment-dashboard .content-block-title .badge', function generateDynamicPageForDashboardFilters(){

	dashboardData = localStorage.getItem("jcp_plus_dashboard_filters_and_views_product_enrichment").split('~')

	dateHtml = 	$$('<ul><li><label class="label-radio item-content"><input type="radio" name="date" value="0"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Today</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="1"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Yesterday</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="2"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="3"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="4"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="5"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="6"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Year</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="7"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Year</div></div></label></li></ul>');
	$$.each(dashboardData[0].split('|'), function(i, item){
		$$(dateHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
	})
	
	viewsHtml = $$('<ul><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="1"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Inflow</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="2"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Allotment</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="3"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Audit</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="4"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Audit Results</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="5"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Defects</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="6"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Remediation</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="7"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Scrubbing Task</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="8"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Remediation Results</div></div></label><div class="sortable-handler"></div></li></ul>');
	dashboardData_array = dashboardData[1].split('|');
	$$.each(dashboardData_array, function(i, item){
		$$(viewsHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
		if( i <= (dashboardData_array.length-1) ){
			$$( $$(viewsHtml).find('input[value="'+dashboardData_array[(i)]+'"]').parents('li') ).insertBefore( $$(viewsHtml).find('li').eq(i) );
		}
	})

    mainView.router.loadContent(
        '   <div data-page="dynamic-dashboard-filters-product-enrichment" class="page html-dynamic-page-dashboard-filters-product-enrichment">' +
        '   <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Filters and views</div>' +
        '      </div>' +
        '    </div>' +
		'	<a href="#" class="floating-button color-red"><i class="material-icons">playlist_add_check</i></a>'+
        '    <div class="page-content">' +
		
        '   <div class="content-block-title" id="filter1">Date</div>' +
		'   <div class="list-block">'+
		' 	<ul>'+
			$$(dateHtml).html() +
		'   </ul>'+
		'   </div>'+

        '   <div class="content-block-title" id="filter2">Views <a href="#" class="link toggle-sortable no-ripple">Edit Order</a></div>' +
		'   <div class="list-block sortable">'+
		' 	<ul>'+
			$$(viewsHtml).html() +
		'   </ul>'+
		'   </div>'+

        '   <br><br><br>' +

        '   </div>' +
        '   </div>'
    );

	var container = $$('.html-dynamic-page-dashboard-filters-product-enrichment .page-content'),
    scrollTo = $$("#" + $$(this).attr('data-scrollto'));
	container.scrollTop(scrollTo.offset().top - container.offset().top + container.scrollTop() - 70, 600);

});

$$(document).on('click', '.html-page-welcome .image-enrichment-dashboard .content-block-title .badge', function generateDynamicPageForDashboardFilters(){

	dashboardData = localStorage.getItem("jcp_plus_dashboard_filters_and_views_image_enrichment").split('~')

	dateHtml = 	$$('<ul><li><label class="label-radio item-content"><input type="radio" name="date" value="0"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Today</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="1"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Yesterday</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="2"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="3"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="4"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="5"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="6"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Year</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="7"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Year</div></div></label></li></ul>');
	$$.each(dashboardData[0].split('|'), function(i, item){
		$$(dateHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
	})

	viewsHtml = $$('<ul><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="1"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Division Standards</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="2"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Technical Issues</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="3"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Fix</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="4"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Status</div></div></label><div class="sortable-handler"></div></li></ul>');
	dashboardData_array = dashboardData[1].split('|');
	$$.each(dashboardData_array, function(i, item){
		$$(viewsHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
		if( i <= (dashboardData_array.length-1) ){
			$$( $$(viewsHtml).find('input[value="'+dashboardData_array[(i)]+'"]').parents('li') ).insertBefore( $$(viewsHtml).find('li').eq(i) );
		}
	})

    mainView.router.loadContent(
        '   <div data-page="dynamic-dashboard-filters-image-enrichment" class="page html-dynamic-page-dashboard-filters-image-enrichment">' +
        '   <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Filters and views</div>' +
        '      </div>' +
        '    </div>' +
		'	<a href="#" class="floating-button color-red"><i class="material-icons">playlist_add_check</i></a>'+
        '    <div class="page-content">' +
		
        '   <div class="content-block-title" id="filter1">Date</div>' +
		'   <div class="list-block">'+
		' 	<ul>'+
			$$(dateHtml).html() +
		'   </ul>'+
		'   </div>'+

        '   <div class="content-block-title" id="filter2">Views <a href="#" class="link toggle-sortable no-ripple">Edit Order</a></div>' +
		'   <div class="list-block sortable">'+
		' 	<ul>'+
			$$(viewsHtml).html() +
		'   </ul>'+
		'   </div>'+
		
        '   <br><br><br>' +

        '   </div>' +
        '   </div>'
    );

	container = $$('.html-dynamic-page-dashboard-filters-image-enrichment .page-content'),
    scrollTo = $$("#" + $$(this).attr('data-scrollto'));
	container.scrollTop(scrollTo.offset().top - container.offset().top + container.scrollTop() - 70, 600);
	
});

$$(document).on('click', '.html-page-welcome .plano-assistance-dashboard .content-block-title .badge', function generateDynamicPageForDashboardFilters(){

	dashboardData = localStorage.getItem("jcp_plus_dashboard_filters_and_views_plano_assistance").split('~')

	dateHtml = 	$$('<ul><li><label class="label-radio item-content"><input type="radio" name="date" value="0"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Today</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="1"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Yesterday</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="2"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="3"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Week</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="4"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="5"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Month</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="6"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">This Year</div></div></label></li><li><label class="label-radio item-content"><input type="radio" name="date" value="7"/><div class="item-media"><i class="icon icon-form-radio"></i></div><div class="item-inner"><div class="item-title">Last Year</div></div></label></li></ul>');
	$$.each(dashboardData[0].split('|'), function(i, item){
		$$(dateHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
	})
	
	viewsHtml = $$('<ul><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="1"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Navigation</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="2"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Title & Copy</div></div></label><div class="sortable-handler"></div></li><li><label class="label-checkbox item-content"><input type="checkbox" name="view" value="3"/><div class="item-media"><i class="icon icon-form-checkbox"></i></div><div class="item-inner"><div class="item-title">Status</div></div></label><div class="sortable-handler"></div></li></ul>');
	dashboardData_array = dashboardData[1].split('|');
	$$.each(dashboardData_array, function(i, item){
		$$(viewsHtml).find('input[value="'+item+'"]').attr('checked', 'checked');
		if( i <= (dashboardData_array.length-1) ){
			$$( $$(viewsHtml).find('input[value="'+dashboardData_array[(i)]+'"]').parents('li') ).insertBefore( $$(viewsHtml).find('li').eq(i) );
		}
	})

    mainView.router.loadContent(
        '   <div data-page="dynamic-dashboard-filters-plano-assistance" class="page html-dynamic-page-dashboard-filters-plano-assistance">' +
        '   <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Filters and views</div>' +
        '      </div>' +
        '    </div>' +
		'	<a href="#" class="floating-button color-red"><i class="material-icons">playlist_add_check</i></a>'+
        '    <div class="page-content">' +

        '   <div class="content-block-title" id="filter1">Date</div>' +
		'   <div class="list-block">'+
		' 	<ul>'+
			$$(dateHtml).html() +
		'   </ul>'+
		'   </div>'+

        '   <div class="content-block-title" id="filter2">Views <a href="#" class="link toggle-sortable no-ripple">Edit Order</a></div>' +
		'   <div class="list-block sortable">'+
		' 	<ul>'+
			$$(viewsHtml).html() +
		'   </ul>'+
		'   </div>'+

        '   <br><br><br>' +

        '   </div>' +
        '   </div>'
    );

	container = $$('.html-dynamic-page-dashboard-filters-plano-assistance .page-content'),
    scrollTo = $$("#" + $$(this).attr('data-scrollto'));
	container.scrollTop(scrollTo.offset().top - container.offset().top + container.scrollTop() - 70, 600);

});

$$(document).on("click", "div[data-page^='dynamic-dashboard-filters-'] .navbar .back, div[data-page^='dynamic-dashboard-filters-'] .floating-button",function(e){

	if($$('[name="date"]:checked').length==0){myApp.alert('Date filter can not be empty. Select at least one date option and retry.', 'Sorry!');return false;}
	if($$('[name="view"]:checked').length==0){myApp.alert('Views filter can not be empty. Select at least one view and retry.', 'Sorry!');return false;}

	selected_dashboard = $$(this).parents('div').find('div[data-page^="dynamic-dashboard-filters-"]').attr('data-page');
	selected_dashboard_item = selected_dashboard.replace('dynamic-dashboard-filters-', '').replace(/-/g, '_');

	date_filters = '';
	views_filters = '';

	$$('div[data-page="'+selected_dashboard+'"] input[name="date"]').each(function(i){
		if($$(this).prop('checked')==true){date_filters = $$(this).val()}
	})

	$$('div[data-page="'+selected_dashboard+'"] input[name="view"]').each(function(i){
		if($$(this).prop('checked')==true){views_filters += $$(this).val() + '|'}
	})
	views_filters = views_filters.substring(0, views_filters.length - 1);

	new_dashboard_filters_and_views = date_filters + '~' + views_filters;

	current_dashboard_filters_and_views = '';if(localStorage.getItem("jcp_plus_dashboard_filters_and_views_"+selected_dashboard_item)){current_dashboard_filters_and_views = localStorage.getItem("jcp_plus_dashboard_filters_and_views_"+selected_dashboard_item)};

	if(current_dashboard_filters_and_views == new_dashboard_filters_and_views){if($$(this).hasClass('floating-button')){mainView.router.back()};return false;}

	localStorage.setItem("jcp_plus_dashboard_filters_and_views_"+selected_dashboard_item, new_dashboard_filters_and_views);

	jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'update_dashboard_filters', dashboard_filters_and_views: selected_dashboard_item + "@" + localStorage.getItem("jcp_plus_dashboard_filters_and_views_" + selected_dashboard_item)});

	makeDashboard(selected_dashboard_item, mySwiper);

	if($$(this).hasClass('floating-button')){mainView.router.back()}

});

function makeDashboard(which_dashboard, mySwiper){
	
	views_selected = localStorage.getItem("jcp_plus_dashboard_filters_and_views_"+which_dashboard).split('~')[1].split('|');
	$$(".swiper-slide."+which_dashboard.replace(/_/g, '-')+"-dashboard .card").hide();
	$$.each(views_selected, function(i, item){
		$$(".swiper-slide."+which_dashboard.replace(/_/g, '-')+"-dashboard .card.view_"+item).show();
		$$(".swiper-slide."+which_dashboard.replace(/_/g, '-')+"-dashboard .card.view_"+item).insertAfter( $$(".swiper-slide."+which_dashboard.replace(/_/g, '-')+"-dashboard .card").eq(i) );
	})

	mySwiper.update();
	
	filter_selected_div = which_dashboard.replace(/_/g, '-')+"-dashboard";
	$$("."+filter_selected_div+" .content-block-title").addClass('disabled')
	
	date_filters = ["Today", "Yesterday", "This Week", "Last Week", "This Month", "Last Month", "This Year", "Last Year"];
	$$("."+filter_selected_div+" .content-block-title .filter1").text(date_filters[localStorage.getItem("jcp_plus_dashboard_filters_and_views_"+which_dashboard).split('~')[0]]);

	$$("."+filter_selected_div+" .amcharts-export-menu").hide();
	/*Need change -->*/$$("."+filter_selected_div+" .card-header .material-icons").hide();
	$$("."+filter_selected_div+" .amcharts_curtain span").html('<i class="material-icons">insert_chart</i><br>Fetching Data...');
	$$("."+filter_selected_div+" .meta_data").hide();
	$$("."+filter_selected_div+" .jcp_plus_amcharts").show();
	$$("."+filter_selected_div+" .amcharts_curtain").show();
	$$("."+filter_selected_div+" .card-footer strong").html('<i class="material-icons">more_horiz</i>');

	
	//Delete expired dashboard data
	for (var i = 0; i < localStorage.length; i++){
		if (localStorage.key(i).substring(0, 28) == 'jcp_plus_dashboard_data_for_' && localStorage.key(i).indexOf('_'+new Date().toIsoString()) == -1 ) {
			localStorage.removeItem(localStorage.key(i));
		}
	}

	if(localStorage.getItem('jcp_plus_dashboard_data_for_'+$$("."+filter_selected_div+" .content-block-title .filter1").text().toLowerCase().replace(/ /g, '_')+'_'+which_dashboard+'_'+new Date().toIsoString())){
		makeDashboard_Step_2_1(which_dashboard, localStorage.getItem('jcp_plus_dashboard_data_for_'+$$("."+filter_selected_div+" .content-block-title .filter1").text().toLowerCase().replace(/ /g, '_')+'_'+which_dashboard+'_'+new Date().toIsoString()))
	} else {
		makeDashboard_Step_2(which_dashboard);
	}

}

function makeDashboard_Step_2(which_dashboard){

	$$.ajax({
		type: "GET",
		contentType: "application/json",
		url: "https://www.maruthigowda.com/JCP+/data?dashboard="+which_dashboard+"&filters_and_views="+encodeURIComponent(localStorage.getItem("jcp_plus_dashboard_filters_and_views_"+which_dashboard)),
		async: true,
		timeout: 300000,
		cache: true,
		success: function(data, status, xhr){	
			//console.log("Response: SUCCESS\n\nStatus: " + status + "\n\nData: " + JSON.stringify(data) + "\n\n" + "XHR: " + JSON.stringify(xhr))
			
			//console.log(data)
			
			if(mainView.activePage.name=='welcome'){
				localStorage.setItem('jcp_plus_dashboard_data_for_'+$$("."+which_dashboard.replace(/_/g, '-')+"-dashboard"+" .content-block-title .filter1").text().toLowerCase().replace(/ /g, '_')+'_'+which_dashboard+'_'+new Date().toIsoString(), data)
				setTimeout(function(){makeDashboard_Step_2_1(which_dashboard, data);}, 1000);
			}
		},
		error: function(xhr, status){
			//console.log(status)
			setTimeout(function(){makeDashboard_Step_2(which_dashboard)}, 1000);
		}
	});
}




function makeDashboard_Step_2_1(which_dashboard, data){

			data = JSON.parse(data);
			
			numbers = data.numbers;

			for(var i = 0; i < $$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card-footer strong').length; i++){
				//console.log(Object.keys(numbers)[i])
				$$("."+which_dashboard.replace(/_/g, '-')+"-dashboard .card-footer strong[data-field='"+Object.keys(numbers)[i]+"']").html('<a>'+Object.values(numbers)[i]+'</a>'+kFormatter(Object.values(numbers)[i]));
			}

			$$.each( $$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card'), function(i, items){

				chart_div_id = which_dashboard+"_dashboard_view_"+(i+1);
				
				chart_data_empty = true;
				$$.each( $$('#'+chart_div_id).parents('.card').find('strong a'), function(x, item){
					if($$(item).text().replace('<a>', '').replace('</a>', '')!='0'){chart_data_empty = false;} ;
				});

				if(chart_data_empty==true){
					$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .card-header .material-icons").hide();
					$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .amcharts-export-menu").hide();
					$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .amcharts_curtain span").html('<i class="material-icons">insert_chart</i><br>No data to plot.');
					$$("."+which_dashboard.replace(/_/g,'-')+"-dashboard .content-block-title").removeClass('disabled');
				} else {
					$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .amcharts_curtain span").html('<i class="material-icons">insert_chart</i><br>Generating chart...');
				}

			});

			if( $$("."+which_dashboard.replace(/_/g,'-')+"-dashboard .filter1").text() == 'Today' || $$("."+which_dashboard.replace(/_/g,'-')+"-dashboard .filter1").text() == 'Yesterday' ){makeDashboard_Step_3_1(which_dashboard, data.chart)}else{makeDashboard_Step_3_2(which_dashboard, data.chart)}
}







function kFormatter(num){return num > 999 ? (num/1000).toFixed(1) + 'K' : num}

function makeDashboard_Step_3_1(which_dashboard, data){

	var chart_data = [];

	if(which_dashboard=='product_enrichment'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		var chart_data_4 = [];
		var chart_data_5 = [];
		var chart_data_6 = [];
		var chart_data_7 = [];
		var chart_data_8 = [];
		
		chart_data_1.push({
			"title": "Factory ship",
			"value": data[0].inflow_factory_ship_items,
			"color": "#E74C3C"
		},{
			"title": "Non factory ship",
			"value": data[0].inflow_non_factory_ship_items,
			"color": "#28B463"
		});
		chart_data_2.push({
			"title": "Allotted",
			"value": data[0].allotted,
			"color": "#28B463"
		},{
			"title": "Pending",
			"value": data[0].pending_allotment,
			"color": "#E74C3C"
		});
		chart_data_3.push({
			"title": "Completed",
			"value": data[0].audit_completed,
			"color": "#28B463"
		},{
			"title": "WIP",
			"value": data[0].audit_wip,
			"color": "#FF8C00"
		},{
			"title": "Pending",
			"value": data[0].audit_pending,
			"color": "#E74C3C"
		});
		chart_data_4.push({
			"title": "Defects",
			"value": data[0].defects,
			"color": "#E74C3C"
		},{
			"title": "No defects",
			"value": data[0].no_defects,
			"color": "#28B463"
		});
		chart_data_5.push({
			"title": "Workable",
			"value": data[0].workable,
			"color": "#28B463"
		},{
			"title": "Non workable",
			"value": data[0].non_workable,
			"color": "#FF8C00"
		},{
			"title": "Both",
			"value": data[0].workable_and_non_workable_both,
			"color": "#E74C3C"
		});
		chart_data_6.push({
			"title": "Completed",
			"value": data[0].remediation_completed,
			"color": "#28B463"
		},{
			"title": "WIP",
			"value": data[0].remediation_wip,
			"color": "#FF8C00"
		},{
			"title": "Pending",
			"value": data[0].remediation_pending,
			"color": "#E74C3C"
		});
		chart_data_7.push({
			"title": "Completed",
			"value": data[0].scrubbing_task_completed,
			"color": "#28B463"
		},{
			"title": "WIP",
			"value": data[0].scrubbing_task_wip,
			"color": "#FF8C00"
		},{
			"title": "Pending",
			"value": data[0].scrubbing_task_pending,
			"color": "#E74C3C"
		});
		chart_data_8.push({
			"title": "Reflecting on website",
			"value": data[0].changes_reflecting_on_website,
			"color": "#28B463"
		},{
			"title": "Not reflecting on website",
			"value": data[0].changes_not_reflecting_on_website,
			"color": "#E74C3C"
		});
	
	chart_data[0] = chart_data_1;
	chart_data[1] = chart_data_2;
	chart_data[2] = chart_data_3;
	chart_data[3] = chart_data_4;
	chart_data[4] = chart_data_5;
	chart_data[5] = chart_data_6;
	chart_data[6] = chart_data_7;
	chart_data[7] = chart_data_8;
}

	else if(which_dashboard=='image_enrichment'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		var chart_data_4 = [];
		
		$$.each(data, function(i, item) {
			chart_data_1.push({
			"title": "Incorrect primary view",
			"value": data[0].incorrect_primary_view,
			"color": "#999999"
			},{
				"title": "Duplicate images",
				"value": data[0].duplicate_images,
				"color": "#999999"
			},{
				"title": "Irrelevant alternative images",
				"value": data[0].irrelevant_alternative_images,
				"color": "#999999"
			});
			chart_data_2.push({
				"title": "white_space_issue",
				"value": data[0].white_space_issue,
				"color": "#999999"
			},{
				"title": "Whiteout background issue",
				"value": data[0].white_out_background_issue,
				"color": "#999999"
			},{
				"title": "Blur issue",
				"value": data[0].blur_issue,
				"color": "#999999"
			},{
				"title": "Duplicate images",
				"value": data[0].duplicate_images,
				"color": "#999999"
			},{
				"title": "Improper dimensions",
				"value": data[0].improper_dimensions,
				"color": "#999999"
			},{
				"title": "Alignment issue",
				"value": data[0].alignment_issue,
				"color": "#999999"
			},{
				"title": "Found taglines or seal",
				"value": data[0].found_tag_lines_or_seal,
				"color": "#999999"
			});
			chart_data_3.push({
				"title": "CCR fix required",
				"value": data[0].ccr_fix_required,
				"color": "#999999"
			},{
				"title": "Swatches required",
				"value": data[0].swatches_required,
				"color": "#999999"
			},{
				"title": "Renaming required",
				"value": data[0].renaming_required,
				"color": "#999999"
			});
			chart_data_4.push({
				"title": "Fixed",
				"value": data[0].status_fixed,
				"color": "#999999"
			},{
				"title": "WIP",
				"value": data[0].status_wip,
				"color": "#999999"
			},{
				"title": "Pending",
				"value": data[0].status_pending,
				"color": "#999999"
			});
		})

		chart_data[0] = chart_data_1;
		chart_data[1] = chart_data_2;
		chart_data[2] = chart_data_3;
		chart_data[3] = chart_data_4;
	}

	else if(which_dashboard=='plano_assistance'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		
		$$.each(data, function(i, item) {
			chart_data_1.push({
				"title": "Not searchable by PP or ENS ID",
				"value": data[0].not_searchable_by_pp_or_ens_id,
				"color": "#999999"
			},{
				"title": "Not searchable by LOT ID",
				"value": data[0].not_searchable_by_lot_id,
				"color": "#999999"
			},{
				"title": "PP or Ensemble mismatch with LOT ID",
				"value": data[0].pp_or_ensemble_mismatch_with_lot_id,
				"color": "#999999"
			});
			chart_data_2.push({
				"title": "Title and copy mismatch",
				"value": data[0].title_and_copy_mismatch,
				"color": "#999999"
			},{
				"title": "Incomplete copy",
				"value": data[0].incomplete_copy,
				"color": "#999999"
			},{
				"title": "Missing mandatory info",
				"value": data[0].missing_mandatory_info,
				"color": "#999999"
			},{
				"title": "Incorrect attributes",
				"value": data[0].incorrect_attributes,
				"color": "#999999"
			});
			chart_data_3.push({
				"title": "Fixed",
				"value": data[0].plano_assistance_status_fixed,
				"color": "#999999"
			},{
				"title": "WIP",
				"value": data[0].plano_assistance_status_wip,
				"color": "#999999"
			},{
				"title": "Pending",
				"value": data[0].plano_assistance_status_pending,
				"color": "#999999"
			});
		})
		
		chart_data[0] = chart_data_1;
		chart_data[1] = chart_data_2;
		chart_data[2] = chart_data_3;
	}

	for(var i = 1; i < (($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card').length)+1);i++){

		if($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card.view_'+i+' .amcharts_curtain span').html()!='<i class="material-icons">insert_chart</i><br>No data to plot.'){

			export_chart_name = ($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .view_'+i+" .card-header").text()).replace(' more_vert', '') + ' for ' + $$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .filter1').text();
		
			AmCharts.makeChart(which_dashboard+"_dashboard_view_"+i, {
				"dataProvider":chart_data[i-1],
				"export": {"fileName": export_chart_name,"libs": {"path": "js/amcharts/libs/"},"enabled":true,"menu":[{"class":"export-main","label":"Export","menu":[{"label":"Download as ...","menu":["PNG","JPG","SVG"]},{"label":"Save data ...","menu":["XLSX","CSV"]},{"label":"Annotate","action":"draw"}]}],"drawing":{"menu":[{"class":"export-drawing","menu":[{"label":"Add ...","menu":[{"label":"Text","action":"text"}]},{"label":"Change ...","menu":[{"label":"Mode ...","action":"draw.modes"},{"label":"Color ...","action":"draw.colors"},{"label":"Size ...","action":"draw.widths"},{"label":"Opactiy ...","action":"draw.opacities"},"UNDO","REDO"]},{"label":"Download as...","menu":["PNG","JPG"]},"CANCEL"]}]}},
				"listeners":[{"event":"rendered","method":function(e){setTimeout(function(){makeDashboard_Step_4(which_dashboard, e.chart.div.id);},2000)}}],
				"hideCredits": true,
				"type": "pie",
				"theme": "light",
				"startDuration": 0,
				"pullOutRadius": 0,
				"titleField": "title",
				"valueField": "value",
				"colorField": "color",
				"balloonText": "",
				"showZeroSlices": true,
				"labelText": "[[percents]]% [[title]]",
				"percentPrecision" : 0
				//"labelsEnabled": false,
				//"radius": "40%",
				//"innerRadius": "50%",
				//"autoMargins":false,"marginLeft":20,"marginRight":20,"marginBottom":20,"marginTop":10
			});

		}
	}
}


function makeDashboard_Step_3_2(which_dashboard, data){

	//console.log(data)
	
	var chart_data = [];
	
	if(which_dashboard=='product_enrichment'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		var chart_data_4 = [];
		var chart_data_5 = [];
		var chart_data_6 = [];
		var chart_data_7 = [];
		var chart_data_8 = [];

		$$.each(data, function(i, item) {
			chart_data_1.push({
				date: item.date,
				inflow__Factory_ship_items__red: item.inflow_factory_ship_items,
				inflow__Non_factory_ship_items__green: item.inflow_non_factory_ship_items
			});
			chart_data_2.push({
				date: item.date,
				allotment__Allotted__green: item.allotted,
				allotment__Pending__red: item.pending_allotment
			});
			chart_data_3.push({
				date: item.date,
				audit__Completed__green: item.audit_completed,
				audit__WIP__orange: item.audit_wip,
				audit__Pending__red: item.audit_pending
			});
			chart_data_4.push({
				date: item.date,
				audit_results__Defects__red: item.defects,
				audit_results__No_defects__green: item.no_defects,
			});
			chart_data_5.push({
				date: item.date,
				defects__Workable__green: item.workable,
				defects__Non_workable__red: item.non_workable,
				defects__Both__blue: item.workable_non_workable_both
			});
			chart_data_6.push({
				date: item.date,
				remediation__Completed__green: item.remediation_completed,
				remediation__WIP__orange: item.remediation_wip,
				remediation__Pending__red: item.remediation_pending
			});
			chart_data_7.push({
				date: item.date,
				scrubbing_task__Completed__green: item.scrubbing_task_completed,
				scrubbing_task__WIP__orange: item.scrubbing_task_wip,
				scrubbing_task__Pending__red: item.scrubbing_task_pending
			});
			chart_data_8.push({
				date: item.date,
				changes__Reflecting_on_website__green: item.changes_reflecting_on_website,
				changes__Not_reflecting_on_website__red: item.changes_not_reflecting_on_website
			});
		})

		chart_data[0] = chart_data_1;
		chart_data[1] = chart_data_2;
		chart_data[2] = chart_data_3;
		chart_data[3] = chart_data_4;
		chart_data[4] = chart_data_5;
		chart_data[5] = chart_data_6;
		chart_data[6] = chart_data_7;
		chart_data[7] = chart_data_8;
	}
	
	else if(which_dashboard=='image_enrichment'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		var chart_data_4 = [];
		
		$$.each(data, function(i, item) {
			chart_data_1.push({
				date: item.date,
				primary_image__Incorrect_primary_view__red: item.incorrect_primary_view,
				primary_image__Duplicate_images__orange: item.duplicate_images,
				primary_image__Irrelevant_alternative_images__blue: item.irrelevant_alternative_images
			});
			chart_data_2.push({
				date: item.date,
				primary_image__White_space_issue__red: item.white_space_issue,
				primary_image__White_out_background_issue__orange: item.white_out_background_issue,
				primary_image__Blur_issue__blue: item.blur_issue,
				primary_image__Improper_dimensions__purple: item.improper_dimensions,
				primary_image__Alignment_issue__navy: item.alignment_issue,
				primary_image__Found_taglines_or_seal__black: item.found_tag_lines_or_seal
			});
			chart_data_3.push({
				date: item.date,
				primary_image__CCR_fix_required__red: item.ccr_fix_required,
				primary_image__Swatches_required__orange: item.swatches_required,
				primary_image__Renaming_required__blue: item.renaming_required
			});
			chart_data_4.push({
				date: item.date,
				status__Fixed__green: item.status_fixed,
				status__WIP__orange: item.status_wip,
				status__Pending__red: item.status_pending
			});
		})
		
		chart_data[0] = chart_data_1;
		chart_data[1] = chart_data_2;
		chart_data[2] = chart_data_3;
		chart_data[3] = chart_data_4;
	}

	else if(which_dashboard=='plano_assistance'){
		var chart_data_1 = [];
		var chart_data_2 = [];
		var chart_data_3 = [];
		
		$$.each(data, function(i, item) {
			chart_data_1.push({
				date: item.date,
				navigation__Not_searchable_by_PP_or_ENS_ID__red: item.pp_or_ensemble_not_searchable_by_pp_or_ens_id,
				navigation__Not_searchable_by_LOT_ID__orange: item.pp_or_ensemble_not_searchable_by_lot_id,
				navigation__Mismatch_with_LOT_ID: item__blue.pp_or_ensemble_mismatch_with_lot_id
			});
			chart_data_2.push({
				date: item.date,
				copy_block__Title_and_copy_mismatch__red: item.title_and_copy_mismatch,
				copy_block__Incomplete_copy__orange: item.incomplete_copy,
				copy_block__Missing_mandatory_info__blue: item.missing_mandatory_info,
				copy_block__Incorrect_attributes__navy: item.incorrect_attributes
			});
			chart_data_3.push({
				date: item.date,
				status__Fixed__green: item.plano_assistance_status_fixed,
				status__WIP__orange: item.plano_assistance_status_wip,
				status__Pending__red: item.plano_assistance_status_pending
			});
		})
		
		chart_data[0] = chart_data_1;
		chart_data[1] = chart_data_2;
		chart_data[2] = chart_data_3;
	}

	for(var i = 1; i < (($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card').length)+1);i++){

		if($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .card.view_'+i+' .amcharts_curtain span').html()!='<i class="material-icons">insert_chart</i><br>No data to plot.'){

			var dynamic_graphs_var = [];
			$$.each(Object.keys(chart_data[i-1][0]),function(i, item){
				if(i==0){return}
				lineColor = '#E74C3C';

				chart_color_red = '#E74C3C';
				chart_color_green = '#28B463';
				chart_color_blue = '#3498DB';
				chart_color_purple = '#7D3C98';
				chart_color_black = '#17202A';
				chart_color_orange = '#FF8C00';
				chart_color_navy = '#8B4513';

				lineColor = window['chart_color_' + item.split('__')[2]];
				
				dynamic_graphs_var.push({"id":"g"+i,"lineColor":lineColor,"valueField":item,"title":item.replace(/_/g, ' '),"bullet":"round","bulletBorderAlpha":1,"bulletColor":"#efefef","bulletSize":5,"hideBulletsCount":50,"lineThickness":2,"useLineColorForBulletBorder":true,"balloonText": "<strong>[[value]]</strong> "+item.split('__')[1].replace(/_/g, ' ')});
				
			});
			
			export_chart_name = ($$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .view_'+i+" .card-header").text()).replace(' more_vert', '') + ' for ' + $$('.'+which_dashboard.replace(/_/g,'-')+'-dashboard .filter1').text();

			AmCharts.makeChart(which_dashboard+"_dashboard_view_"+i, {
				"dataProvider":chart_data[i-1],
				"export": {"fileName": export_chart_name,"libs": {"path": "js/amcharts/libs/"},"enabled":true,"menu":[{"class":"export-main","label":"Export","menu":[{"label":"Download as ...","menu":["PNG","JPG","SVG"]},{"label":"Save data ...","menu":["XLSX","CSV"]},{"label":"Annotate","action":"draw"}]}],"drawing":{"menu":[{"class":"export-drawing","menu":[{"label":"Add ...","menu":[{"label":"Text","action":"text"}]},{"label":"Change ...","menu":[{"label":"Mode ...","action":"draw.modes"},{"label":"Color ...","action":"draw.colors"},{"label":"Size ...","action":"draw.widths"},{"label":"Opactiy ...","action":"draw.opacities"},"UNDO","REDO"]},{"label":"Download as...","menu":["PNG","JPG"]},"CANCEL"]}]}},
				"listeners":[{"event":"rendered","method":function(e){setTimeout(function(){makeDashboard_Step_4(which_dashboard, e.chart.div.id)},2000)}}],
				"hideCredits": true,
				"zoomOutText":"",
				"type":"serial",
				"theme":"light",
				"dataDateFormat":"YYYY-MM-DD",
				"autoMargins":false,"marginLeft":20,"marginRight":20,"marginBottom":20,"marginTop":10,
				"valueAxes":[{"id": "v1","position":"left","autoGridCount":false,"axisAlpha":0,"axisThickness":0,"labelsEnabled":false,"gridThickness":0,"dashLength":0,"gridColor":"#efefef"}],
				"graphs": dynamic_graphs_var,
				"chartCursor":{"pan":true,"valueLineEnabled":true,"valueLineBalloonEnabled":true,"cursorAlpha":0.2,"valueLineAlpha":0.2,"categoryBalloonDateFormat":"EEE, D MMM YYYY","valueLineBalloonEnabled":false,"valueLineAlpha":0},"categoryField":"date","categoryAxis":{"parseDates":true,"dashLength":1,"minorGridEnabled":true,"labelsEnabled":false,"gridThickness":0,"axisThickness":0,"labelFunction": function(value) {var date = new Date(value);return AmCharts.formatDate(date, "EEE, D MMM YYYY");}},"balloon":{"borderThickness":1,"shadowAlpha":0}
			});
		}
	}
}

function makeDashboard_Step_4(which_dashboard, chart_div_id){
	//$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .card-header .material-icons").hide();
	$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .amcharts-export-menu").show();
	$$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .amcharts_curtain").hide();
	$$("."+which_dashboard.replace(/_/g,'-')+"-dashboard .content-block-title").removeClass('disabled');
	fill_meta_data_after_amcharts_load('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_'), $$('.'+(chart_div_id).replace(/_/g,'-').replace('-view-',' .view_')+" .card-footer strong").attr("data-field") )
}

$$(document).on("click", ".html-page-welcome .card-footer .row div", function(){
	
	which_dashboard = $$('div[data-page="welcome"] .swiper-slide-active .filter2').text().toLowerCase().replace(/ /g, '_');
	
	meta_data_string = localStorage.getItem('jcp_plus_dashboard_data_for_'+$$("."+which_dashboard.replace(/_/g, '-')+"-dashboard"+" .content-block-title .filter1").text().toLowerCase().replace(/ /g, '_')+'_'+which_dashboard+'_'+new Date().toIsoString());
	meta_data_json = JSON.parse(meta_data_string);
	
	if(!meta_data_json['meta_data'][$$(this).parents('.card').find('.card-footer strong').attr("data-field")]){return false;}
	
	if($$(this).parents('.card').find('.meta_data').css("display")=='none'){
		$$(this).parents('.card').find('.jcp_plus_amcharts').hide();
		$$(this).parents('.card').find('.meta_data').show();
		$$(this).parents('.card').find('.card-header i').text('settings_backup_restore').show();
	} else {
		$$(this).parents(".card").find(".meta_data").hide();
		$$(this).parents(".card").find(".jcp_plus_amcharts").show();
		$$(this).parents('.card').find('.card-header i').text('more_vert').hide();
	}
});

function fill_meta_data_after_amcharts_load(which_view,which_meta_data){
	
	which_dashboard = $$('div[data-page="welcome"] .swiper-slide-active .filter2').text().toLowerCase().replace(/ /g, '_');
	
	meta_data_string = localStorage.getItem('jcp_plus_dashboard_data_for_'+$$("."+which_dashboard.replace(/_/g, '-')+"-dashboard"+" .content-block-title .filter1").text().toLowerCase().replace(/ /g, '_')+'_'+which_dashboard+'_'+new Date().toIsoString());
	meta_data_json = JSON.parse(meta_data_string);
	
	if(!meta_data_json['meta_data'][which_meta_data]){return false;}

	meta_data_array = (meta_data_json['meta_data'][which_meta_data]).split('|');

	meta_data_final_array = {};

	for(var i=0; i < meta_data_array.length; i++){
		if(meta_data_array[i]){
			dimension_1 = meta_data_array[i].split(',')[0];
			dimension_2 = meta_data_array[i].split(',')[1];
			dimension_3 = meta_data_array[i].split(',')[2];
			meta_data_final_array[dimension_1] += ',' + dimension_2 + '=' + dimension_3;
		}
	}
	
	meta_data_html = '';
	$$.each(meta_data_final_array, function(i, item){
		if(meta_data_final_array[i]){
		aaaa = item.split(',');
		green = '0';
		blue = '0';
		red = '0';
		for(var x=0; x < aaaa.length; x++){
			if(aaaa[x].indexOf('green')!=-1){green=aaaa[x].replace('green=','')}
			if(aaaa[x].indexOf('blue')!=-1){blue=aaaa[x].replace('blue=','')}
			if(aaaa[x].indexOf('red')!=-1){red=aaaa[x].replace('red=','')}
		}
		
		if(which_meta_data=='audit_completed'){meta_data_html += '<li><a href="#" class="item-link item-content"><div class="item-media"><img src="https://www.maruthigowda.com/JCP+/file/user/'+(i.toString().toLowerCase()).replace(/ /g, '-')+'.jpg" style="width:28px;height:28px"></div><div class="item-inner"><div class="item-title">'+i+'</div><div class="item-after"><span class="badge color-green">'+green+'</span><span class="badge color-blue">'+blue+'</span><span class="badge color-red">'+red+'</span></div></div></a></li>';}
		if(which_meta_data=='remediation_completed'){meta_data_html += '<li><a href="#" class="item-link item-content"><div class="item-media"><img src="https://www.maruthigowda.com/JCP+/file/user/'+(i.toString().toLowerCase()).replace(/ /g, '-')+'.jpg" style="width:28px;height:28px"></div><div class="item-inner"><div class="item-title">'+i+'</div><div class="item-after"><span class="badge color-green">'+green+'</span><span class="badge color-blue">'+blue+'</span><span class="badge color-red">'+red+'</span></div></div></a></li>';}
		if(which_meta_data=='allotted'){division = i;if(division=='0'){division='Salon'}else if(division=='1'){division='Women\'s Accessories'}else if(division=='2'){division='Men\'s'}else if(division=='3'){division='Kids'}else if(division=='4'){division='Home'}else if(division=='5'){division='Jewelry'}else if(division=='6'){division='Div 6'}else if(division=='7'){division='Shoes & Handbags'}else if(division=='8'){division='Women\'s Apparel'}else if(division=='9'){division='Sephora'}meta_data_html += '<li><a href="#" class="item-link item-content"><div class="item-inner"><div class="item-title">'+division+'</div><div class="item-after"><span class="badge color-green">'+green+'</span><span class="badge color-red">'+red+'</span></div></div></a></li>';}
		if(which_meta_data=='defects'){meta_data_html += '<li><a href="#" class="item-link item-content"><div class="item-inner"><div class="item-title">'+i+'</div><div class="item-after"><span class="badge color-red">'+red+'</span></div></div></a></li>';}
	}
	});
	$$(which_view).find('.meta_data').html('<div class="list-block"><ul>'+meta_data_html+'</ul></div>');
};

$$(document).on("dblclick", ".html-page-welcome .card-footer .row div", function(){
	if($$(this).find("strong a").length>0){myApp.alert( $$(this).find("strong a").text(), $$(this).find("i").html().replace('<br>', ' ') );}
});

myApp.onPageInit('site-audit-assistant', function (page){	
	jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'get_site_audit_new_allotment_and_backlog'});
})

$$(document).on('click', '.generate-dynamic-page-for-site-audit-assistant-settings', function generateDynamicPageForSiteAuditAssistantSettings(){
	settingInfo = localStorage.getItem("jcp_plus_site_audit_assistant_settings").split('|');
	settings_1 = 'false';if(settingInfo[0]==1){settings_1='checked'}
	settings_2 = 'false';if(settingInfo[1]==1){settings_2='checked'}
	settings_3 = 'false';if(settingInfo[2]==1){settings_3='checked'}
	settings_4 = 'false';if(settingInfo[3]==1){settings_4='checked'}

    mainView.router.loadContent(
        '  <div data-page="dynamic-site-audit-assistant-settings" class="page html-dynamic-page-site-audit-assistant-settings">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">Assistant Settings</div>' +
        '      </div>' +
        '    </div>' +
        '    <div class="page-content">' +
        '    <div class="content-block-title">Control how Site Audit Assistant works for you.</div>' +
		'   <div class="list-block">'+
		' 	<ul>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'		<div class="item-media"><i class="material-icons">help_outline</i></div>'+
		'         <div class="item-title">Help guide (SOP)</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="help_guide" '+settings_1+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'		<div class="item-media"><i class="material-icons">center_focus_strong</i></div>'+
		'         <div class="item-title">Focus mode</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="focus_mode" '+settings_2+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'		<div class="item-media"><i class="material-icons">keyboard_voice</i></div>'+
		'         <div class="item-title">Voice commands</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="voice_commands" '+settings_3+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'     <li>'+
		'       <div class="item-content">'+
		'       <div class="item-inner"> '+
		'		<div class="item-media"><i class="material-icons">settings_cell</i></div>'+
		'         <div class="item-title">Audit from mobile</div>'+
		'         <div class="item-after"><label class="label-switch"><input type="checkbox" class="mobile_aubit" '+settings_4+'><div class="checkbox"></div></label></div>'+
		'       </div>'+
		'       </div>'+
		'     </li>'+
		'   </ul>'+
		'   </div>'+
        '    </div>' +
        '  </div>'
    );
});

$$(document).on("change", ".html-dynamic-page-site-audit-assistant-settings .label-switch input[type='checkbox']",function(){

	var settingInfo = (localStorage.getItem("jcp_plus_site_audit_assistant_settings")).split('|');
	var settings_1 = settingInfo[0];
	var settings_2 = settingInfo[1];
	var settings_3 = settingInfo[2];
	var settings_4 = settingInfo[3];

	var settings_checked = '';
	if($$(this).prop("checked")==true){settings_checked='1'}else{settings_checked='0'}

	if($$(this).attr("class")=='help_guide'){settings_1=settings_checked}
	else if($$(this).attr("class")=='focus_mode'){settings_2=settings_checked}
	else if($$(this).attr("class")=='voice_commands'){settings_3=settings_checked}
	else if($$(this).attr("class")=='mobile_aubit'){settings_4=settings_checked}

	localStorage.setItem("jcp_plus_site_audit_assistant_settings", settings_1+'|'+settings_2+'|'+settings_3+'|'+settings_4)
	
	jcp_plus_http_post_api('background', {device: jcp_plus_app, version: jcp_plus_version, jcp_plus_passcode: jcp_plus_passcode, todo: 'update_site_audit_assistant_settings', site_audit_assistant_settings: localStorage.getItem("jcp_plus_site_audit_assistant_settings")});
});


function save_site_audit_new_allotment_and_backlog_numbers(arguments){
	//console.log(arguments.site_audit_new_allotment)
	localStorage.setItem("jcp_plus_site_audit_new_allotment", JSON.stringify(arguments.site_audit_new_allotment))
	localStorage.setItem("jcp_plus_site_audit_backlog", JSON.stringify(arguments.site_audit_backlog))

	new_allotment_count = JSON.parse(JSON.stringify(arguments.site_audit_new_allotment)).length
	backlog_count = JSON.parse(JSON.stringify(arguments.site_audit_backlog)).length

	new_allotment_bg = 'green';if(localStorage.getItem("jcp_plus_site_audit_new_allotment").indexOf('|0|')!=-1||localStorage.getItem("jcp_plus_site_audit_new_allotment").indexOf('|1|')!=-1){new_allotment_bg='red'}
	backlog_bg = 'green';if(localStorage.getItem("jcp_plus_site_audit_backlog").indexOf('|0|')!=-1||localStorage.getItem("jcp_plus_site_audit_backlog").indexOf('|1|')!=-1){backlog_bg='red'}

	jcp_plus_audit_recommendation = 'Audit your new allotment.';
	if(backlog_bg=='red'){jcp_plus_audit_recommendation = 'Finish your backlog.'}
	else if(new_allotment_bg=='green'&&backlog_bg=='green'&&new_allotment_count=='0'){jcp_plus_audit_recommendation = 'No allotment. Have Fun.'}
	else{jcp_plus_audit_recommendation = 'Well done! Thank you.';}
	$$('.page-site-audit-assistant .content-block-title').html(jcp_plus_audit_recommendation+'<i class="material-icons">refresh</i></a>');

	$$('.page-site-audit-assistant .list-block .item-link .item-inner').css('background-position', 'calc(100% - 16px) center');

	$$('.page-site-audit-assistant .generate-dynamic-page-for-site-audit-assistant-new-allotment .item-after').html('<span class="badge bg-'+new_allotment_bg+'">'+new_allotment_count+'</span>');
	$$('.page-site-audit-assistant .generate-dynamic-page-for-site-audit-assistant-backlog .item-after').html('<span class="badge bg-'+backlog_bg+'">'+backlog_count+'</span>');
}

$$(document).on('click', '.page-site-audit-assistant .content-block-title i', function(){
	mainView.router.refreshPage()
})

$$(document).on('click', '.generate-dynamic-page-for-site-audit-assistant-new-allotment, .generate-dynamic-page-for-site-audit-assistant-backlog', function(){
	if($$(this).find('.item-after .badge').length==0){return false;}

	new_allotment_or_backlog = ''
	zero_allotment_or_backlog_message = ''

	if($$(this).hasClass('generate-dynamic-page-for-site-audit-assistant-new-allotment')){
		new_allotment_or_backlog = 'new_allotment'
		zero_allotment_or_backlog_message = 'You don\'t have any new allotment.|We\'re sorry, Warrior!'
		new_allotment_or_backlog_title = 'New Allotment'
	} else {
		new_allotment_or_backlog = 'backlog'
		zero_allotment_or_backlog_message = 'You don\'t have any backlog.<br>|Well done, Warrior!'
		new_allotment_or_backlog_title = 'Backlog'
	}

	if($$(this).find('.item-after .badge').text()=='0'){myApp.alert(zero_allotment_or_backlog_message.split('|')[0],zero_allotment_or_backlog_message.split('|')[1]);return false;}

	NewAllotmentOrBacklogArray = JSON.parse(localStorage.getItem("jcp_plus_site_audit_"+new_allotment_or_backlog));
	
	new_allotment_or_backlog_html = '';

	for(var i = 0; i < NewAllotmentOrBacklogArray.length; i++){
		NewAllotmentOrBacklogInfo = NewAllotmentOrBacklogArray[i].split('|');
		status_html = NewAllotmentOrBacklogInfo[4];
		if(status_html=='0'){status_html_id = 'pending_audit'; status_html = '<span class="badge">Pending Audit</span>';}else if(status_html=='1'){status_html_id = 'ongoing_audit'; status_html = '<span class="badge">Ongoing Audit</span>';}else if(status_html=='2'){status_html_id = 'completed_audit'; status_html = '<span class="badge">Audit Completed</span>';}
		AllocationDateTime = NewAllotmentOrBacklogInfo[6].split('-');AllocationDateTime = AllocationDateTime[2]+'-'+AllocationDateTime[1]+'-'+AllocationDateTime[0];
		new_allotment_or_backlog_html += '<li class="item-content '+status_html_id+'" data-id="'+NewAllotmentOrBacklogInfo[0]+'|'+NewAllotmentOrBacklogInfo[1]+'|'+NewAllotmentOrBacklogInfo[2]+'|'+NewAllotmentOrBacklogInfo[3]+'|'+status_html_id+'|'+(NewAllotmentOrBacklogInfo[5]).replace(/\"/g, "'jcp_plus_double_quote'")+'|'+AllocationDateTime+'|'+NewAllotmentOrBacklogInfo[7]+'"><div class="item-inner"><div class="item-title">'+NewAllotmentOrBacklogInfo[2]+'</div></i>'+status_html+'</div></li>';
	}
	
	pending_or_completed_count =  '0 PENDING|green';
	if( ( (new_allotment_or_backlog_html.match(/Pending Audit/g) || []).length + (new_allotment_or_backlog_html.match(/Ongoing Audit/g) || []).length ) > 0 ){
		pending_or_completed_count =  ( (new_allotment_or_backlog_html.match(/Pending Audit/g) || []).length + (new_allotment_or_backlog_html.match(/Ongoing Audit/g) || []).length ) + ' PENDING|red';
	}

    mainView.router.loadContent(
        '  <div data-page="dynamic-site-audit-assistant-'+new_allotment_or_backlog.replace(/_/g, '-')+'" class="page html-dynamic-page-site-audit-assistant-'+new_allotment_or_backlog.replace(/_/g, '-')+'">' +
        '    <div class="navbar">' +
        '      <div class="navbar-inner">' +
        '        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
        '        <div class="center">'+new_allotment_or_backlog_title+'</div>' +
        '		 <div class="right"><a href="#" class="link icon-only assistant-control-button"><i class="material-icons">send</i></a><a href="#" class="link icon-only show-views-selector"><i class="material-icons">more_vert</i></a></div>' +
        '      </div>' +
        '    </div>' +
		'    <form data-search-list=".search-here" data-search-in=".item-title" class="searchbar searchbar-init"><div class="searchbar-input"><input type="search" placeholder="Search"/><a href="#" class="searchbar-clear"></a></div></form>'+
		'	<div class="searchbar-overlay"></div>'+
        '    <div class="page-content">' +
        '    <div class="content-block-title">PFB your '+new_allotment_or_backlog_title.toLowerCase()+'.</div>' +
		'	 <div class="button button-fill color-'+pending_or_completed_count.split('|')[1]+' pending_or_completed_count">'+pending_or_completed_count.split('|')[0]+'</div>' +
		'   <div class="list-block searchbar-not-found"><ul><li class="item-content"><div class="item-inner"><div class="item-title">Sorry! No such product found.</div></div></li></ul></div>'+
		'   <div class="list-block search-here searchbar-found"><ul>'+new_allotment_or_backlog_html+'</ul>'+
		'   </div>'+
        '   </div>' +
        '  </div>'
    );

});

$$(document).on("click", ".html-dynamic-page-site-audit-assistant-new-allotment .show-views-selector, .html-dynamic-page-site-audit-assistant-backlog .show-views-selector", function(){
	new_allotment_or_backlog = ''
	if( mainView.activePage.name == 'dynamic-site-audit-assistant-new-allotment' ){
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-new-allotment'
	} else {
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-backlog'
	}
	
	actionSheetButtons = [
        [
            {
                text: 'Choose a view',
                label: true
            },
            {
                text: 'Product ID',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[2] );
					})
                }
            },
            {
                text: 'LOT numbers',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[3].replace(/,/g, ', ') );
					})
                }
            },
            {
                text: 'Division',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						division = $$(this).attr('data-id').split('|')[1].replace('#', '');if(division=='0'){division='Salon'}else if(division=='1'){division='Women\'s Accessories'}else if(division=='2'){division='Men\'s'}else if(division=='3'){division='Kids'}else if(division=='4'){division='Home'}else if(division=='5'){division='Jewelry'}else if(division=='6'){division='Div 6'}else if(division=='7'){division='Shoes & Handbags'}else if(division=='8'){division='Women\'s Apparel'}else if(division=='9'){division='Sephora'}
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[1] + '. ' + division );
					})
                }
            },
			{
                text: 'Factory ship or non factory ship',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[7] );
					})
                }
            },
            {
                text: 'Product title',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[5].replace(/'jcp_plus_double_quote'/g, '"') );
					})
                }
            },
            {
                text: 'Allotment Date',
                onClick: function () {
					$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li').each(function(i, item){
						$$(this).find('.item-title').text( $$(this).attr('data-id').split('|')[6] );
					})
                }
            },
        ],
        [
            {
                text: 'Cancel',
                color: 'red'
            }
        ]
    ];
	myApp.actions(actionSheetButtons);
});

$$(document).on("dblclick", ".html-dynamic-page-site-audit-assistant-new-allotment ul li, .html-dynamic-page-site-audit-assistant-backlog ul li", function(){
	data = $$(this).attr("data-id").split('|')
	division = data[1].replace('#', '');if(division=='0'){division='Salon'}else if(division=='1'){division='Women\'s Accessories'}else if(division=='2'){division='Men\'s'}else if(division=='3'){division='Kids'}else if(division=='4'){division='Home'}else if(division=='5'){division='Jewelry'}else if(division=='6'){division='Div 6'}else if(division=='7'){division='Shoes & Handbags'}else if(division=='8'){division='Women\'s Apparel'}else if(division=='9'){division='Sephora'}
	myApp.alert( '<strong>Lot numbers</strong><br>' + data[3].replace(/,/g, ', ') + '<br><br><strong>Division</strong><br>' + data[1] + '. ' +division + '<br><br><strong>FS or NFS</strong><br>' + data[7] + '<br><br><strong>Product title</strong><br>' + data[5].replace(/'jcp_plus_double_quote'/g, '"'), data[2].toUpperCase() );
});

$$(document).on("click", ".html-dynamic-page-site-audit-assistant-new-allotment .assistant-control-button, .html-dynamic-page-site-audit-assistant-backlog .assistant-control-button", function() {

	new_allotment_or_backlog = ''
	if( mainView.activePage.name == 'dynamic-site-audit-assistant-new-allotment' ){
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-new-allotment'
	} else {
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-backlog'
	}

	message_to_background_js = '';
	if($$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.ongoing_audit').length>0){
		message_to_background_js = $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.ongoing_audit').attr('data-id');
	}else if($$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.pending_audit').length>0){
		message_to_background_js = $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.pending_audit').attr('data-id');
	}

	if($$(this).hasClass('rotate-animation')){
		$$('.'+new_allotment_or_backlog+' .navbar .back').removeClass('disabled');
		$$(this).hide().removeClass('rotate-animation').html('<i class="material-icons">send</i>');
		setTimeout(function(){
			$$('.'+new_allotment_or_backlog+' .assistant-control-button').show();
			$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"] .badge').text('Audit Paused');
			chrome.runtime.sendMessage({jcp_plus__site_audit_assistant__stop: true});
		},1234);
	} else {
		$$('.'+new_allotment_or_backlog+' form .searchbar-clear').click();
		$$('.'+new_allotment_or_backlog+' .navbar .back').addClass('disabled');
		$$(this).hide().html('<i class="material-icons">toys</i>').addClass('rotate-animation');
		setTimeout(function(){
			$$('.'+new_allotment_or_backlog+' .assistant-control-button').show();
			if(message_to_background_js!=''){
				scroll_container = $$('.'+new_allotment_or_backlog+' .page-content');
				scroll_container.scrollTop(((scroll_container.scrollTop() + $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"]').offset().top) - 192),600);
			}
			setTimeout(function(){
				if(message_to_background_js==''){
					myApp.alert('You have completed your audit quota for the day. Have fun.', 'Well done, Warrior!', function(){$$('.'+new_allotment_or_backlog+' .assistant-control-button').removeClass('rotate-animation');$$('.'+new_allotment_or_backlog+' .assistant-control-button').html('<i class="material-icons">send</i>');$$('.'+new_allotment_or_backlog+' .navbar .back').removeClass('disabled');});mainView.router.refreshPreviousPage();return false;
				}
				localStorage.setItem('jcp_plus__site_audit_assistant__input',message_to_background_js);
				$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"]').removeClass('pending_audit').addClass('ongoing_audit').find('.badge').text('Ongoing Audit');
				chrome.runtime.sendMessage({jcp_plus__site_audit_assistant__start: message_to_background_js});
			},1234);
		},1234);
	}
});

plus_SiteAuditAssistant_Interval = setInterval(function(){
	if(mainView.activePage.name!='dynamic-site-audit-assistant-new-allotment'&&mainView.activePage.name!='dynamic-site-audit-assistant-backlog'){return false;}
	if(localStorage.getItem('jcp_plus__site_audit_assistant__input') && localStorage.getItem('jcp_plus__site_audit_assistant__input').indexOf('|next') != -1){

		new_allotment_or_backlog = ''
		if( mainView.activePage.name == 'dynamic-site-audit-assistant-new-allotment' ){
			new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-new-allotment';
		} else {
			new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-backlog';
		}

		message_from_background_js = localStorage.getItem("jcp_plus__site_audit_assistant__input").replace('|next', '');
		console.log(message_from_background_js);
		$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').removeClass('ongoing_audit')
		$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').addClass('completed_audit')
		$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').find('.badge').text('Audit Completed');
		$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').attr('data-id', $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').attr('data-id').replace('|pending_audit', '|completed_audit').replace('|ongoing_audit', '|completed_audit') )
		localStorage.removeItem("jcp_plus__site_audit_assistant__input");

		message_to_background_js = '';
		if($$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.ongoing_audit').length>0){
			message_to_background_js = $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.ongoing_audit').attr('data-id');
		}else if($$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.pending_audit').length>0){
			message_to_background_js = $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li.pending_audit').attr('data-id');
		}
		
		$$('.'+new_allotment_or_backlog+' form .searchbar-clear').click();

		setTimeout(function(){
			if(message_to_background_js!=''){
				scroll_container = $$('.'+new_allotment_or_backlog+' .page-content');
				scroll_container.scrollTop(((scroll_container.scrollTop() + $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_from_background_js.split('|')[0]+'"]').offset().top) - 192),600);
			}
			setTimeout(function(){

				pending_or_completed_count =  '0 PENDING|green';
				new_allotment_or_backlog_html = $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found').html();
				if( ( (new_allotment_or_backlog_html.match(/Pending Audit/g) || []).length + (new_allotment_or_backlog_html.match(/Ongoing Audit/g) || []).length ) > 0 ){
					pending_or_completed_count =  ( (new_allotment_or_backlog_html.match(/Pending Audit/g) || []).length + (new_allotment_or_backlog_html.match(/Ongoing Audit/g) || []).length ) + ' PENDING|red';
				}

				$$('.'+new_allotment_or_backlog+' .pending_or_completed_count').text( pending_or_completed_count.split('|')[0] )
				$$('.'+new_allotment_or_backlog+' .pending_or_completed_count').removeClass('color-red').removeClass('color-green').addClass('color-'+pending_or_completed_count.split('|')[1])

				if(message_to_background_js==''){
					myApp.alert('You have completed your audit quota for the day. Have fun.', 'Well done, Warrior!', function(){$$('.'+new_allotment_or_backlog+' .assistant-control-button').removeClass('rotate-animation');$$('.'+new_allotment_or_backlog+' .assistant-control-button').html('<i class="material-icons">send</i>');$$('.'+new_allotment_or_backlog+' .navbar .back').removeClass('disabled');});mainView.router.refreshPreviousPage();return false;
				}
				localStorage.setItem('jcp_plus__site_audit_assistant__input',message_to_background_js);
				$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"]').removeClass('pending_audit').addClass('ongoing_audit').find('.badge').text('Ongoing Audit');
				chrome.runtime.sendMessage({jcp_plus__site_audit_assistant__start: message_to_background_js});
			},1234);
		},1234);

	}
}, 1234)


$$(document).on("click", ".html-dynamic-page-site-audit-assistant-new-allotment .completed_audit .badge, .html-dynamic-page-site-audit-assistant-backlog .completed_audit .badge", function() {

	new_allotment_or_backlog = ''
	if( mainView.activePage.name == 'dynamic-site-audit-assistant-new-allotment' ){
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-new-allotment'
	} else {
		new_allotment_or_backlog = 'html-dynamic-page-site-audit-assistant-backlog'
	}

	if($$('.'+new_allotment_or_backlog+' .navbar .back').hasClass('disabled')){return false}

	message_to_background_js = $$(this).parents('.completed_audit').attr('data-id');

	$$('.'+new_allotment_or_backlog+' form .searchbar-clear').click();
	$$('.'+new_allotment_or_backlog+' .navbar .back').addClass('disabled');
	$$('.'+new_allotment_or_backlog+' .assistant-control-button').hide().html('<i class="material-icons">toys</i>').addClass('rotate-animation');
	setTimeout(function(){
		$$('.'+new_allotment_or_backlog+' .assistant-control-button').show();
		scroll_container = $$('.'+new_allotment_or_backlog+' .page-content');
		scroll_container.scrollTop(((scroll_container.scrollTop() + $$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"]').offset().top) - 192),600);
		setTimeout(function(){
			localStorage.setItem('jcp_plus__site_audit_assistant__input',message_to_background_js);
			$$('.'+new_allotment_or_backlog+' .list-block.searchbar-found ul li[data-id^="'+message_to_background_js.split('|')[0]+'"]').removeClass('completed_audit').addClass('ongoing_audit').find('.badge').text('Auditing Again');
			chrome.runtime.sendMessage({jcp_plus__site_audit_assistant__start: message_to_background_js});
		},1234);
	},1234);

})



myApp.onPageInit('dynamic-dashboard-filters-product-enrichment', function (page) {
    $$('.list-block.sortable').on('open', function () {
        $$('.toggle-sortable').text('Done');
    });
    $$('.list-block.sortable').on('close', function () {
        $$('.toggle-sortable').text('Edit Order');
    });
});

myApp.onPageInit('dynamic-dashboard-filters-image-enrichment', function (page) {
    $$('.list-block.sortable').on('open', function () {
        $$('.toggle-sortable').text('Done');
    });
    $$('.list-block.sortable').on('close', function () {
        $$('.toggle-sortable').text('Edit Order');
    });
});

myApp.onPageInit('dynamic-dashboard-filters-plano-assistance', function (page) {
    $$('.list-block.sortable').on('open', function () {
        $$('.toggle-sortable').text('Done');
    });
    $$('.list-block.sortable').on('close', function () {
        $$('.toggle-sortable').text('Edit Order');
    });
});



$$(document).on("click", ".page-image-scrubbing-assistant .assistant-control-button", function() {
	chrome.cookies.set({
    "url": "https://www.jcpenney.com/",
	"domain": "jcpenney.com",
	"path": "/",
    "name": "yoda-desktop",
    "value": "true",
	"name": "yoda-pdp",
    "value": "true"
}, function (cookie) {
	textarea = $$('.page-image-scrubbing-assistant textarea').val().trim();
	if(textarea==''){myApp.alert("Provide one or more PPIDs.", "Sorry! We can't proceed..!!", function(){$$('.page-image-scrubbing-assistant textarea').focus()});;return false;}
	$$("body").css("max-width", "800px");
	$$(".assistant-control-button").hide().addClass('rotate-animation');
	$$('.page-image-scrubbing-assistant .content-block p').eq(1).html('Please wait...');
	$$('.page-image-scrubbing-assistant textarea').hide();
	input_array_raw = textarea.split('\n');
	input_array_final = '';
	for(var i=0;i<input_array_raw.length;i++){
		if( input_array_raw[i].trim()!='' && input_array_final.indexOf(input_array_raw[i].trim() + '|') == -1 ){
			input_array_final +=  input_array_raw[i].trim() + '|';
		}
	}
	input_array_final = input_array_final.substring(0, input_array_final.length-1)
	input = input_array_final.split('|');
	for (var i=0; i<input.length;i++){
		(function(i, total, ppid, url){
			setTimeout(function() { image_scrubbing_assistant__ajax_get(i, total, ppid, url); }, i * 1000);
		})( i, input.length, input[i], 'https://search-api.jcpenney.com/v1/s/'+input[i]+'?Ntt='+input[i] );
	}

})
})

function image_scrubbing_assistant__ajax_get(i, total, ppid, url){

console.log(ppid+' : '+url);

$$.ajax({
	type: "GET",
	url: url,
	async: true,
	timeout: 10000,
	success: function(data, status, xhr) {

		if(data.indexOf('"productDetails":{}')==-1&&data.indexOf('"productDetails":')!=-1){
			json = data.substring(data.indexOf('window.__PRELOADED_STATE__=') + 27, data.indexOf('"redirectData":{}}') + 18);				
			image_scrubbing_assistant__filter_and_write_data(total, ppid, json);
		}
		else if(data.indexOf('"keywordRedirectUrl":"')==-1){
			image_scrubbing_assistant__filter_and_write_data(total, ppid, 'Product not found');
		}
		else if(data.indexOf('"keywordRedirectUrl":"')!=-1){
			
			try{
			api = JSON.parse(data);
			url = 'https://www.jcpenney.com' + api.keywordRedirectUrl;
			image_scrubbing_assistant__ajax_get(i, total, ppid, url);
			return false;
			}catch(e){
			image_scrubbing_assistant__filter_and_write_data(total, ppid, 'API error');
			return false;
			}
						
		}
		else if(data.indexOf('"commonData":{}')!=-1){
			image_scrubbing_assistant__ajax_get(i, total, ppid, 'https://search-api.jcpenney.com/v1/f/filterContent/products?productIds='+ppid);
			return false;
		}
		else if(data.indexOf('{"products":[{')!=-1&&data.indexOf('"pdpUrl":"')!=-1){
			url = 'https://www.jcpenney.com/p/' + (data.substring(data.indexOf('"pdpUrl":"') + 10, data.indexOf('","availabilityStatus":') + 23)).split('/p/')[1];
			image_scrubbing_assistant__ajax_get(i, total, ppid, url);
			return false;
		} else {
			image_scrubbing_assistant__filter_and_write_data(total, ppid, 'Invalid JSON response');
		}

	},
	error: function(xhr, status) {
		if(xhr.status==404) {
			image_scrubbing_assistant__filter_and_write_data(total, ppid, '404 error');
		}
		else if(xhr.status==500) {
			image_scrubbing_assistant__filter_and_write_data(total, ppid, '500 error');
		}
		else if(xhr.status==403) {
			image_scrubbing_assistant__filter_and_write_data(total, ppid, 'IP blocked');
		}
		else if (status == "timeout") {
			setTimeout(function() {
				image_scrubbing_assistant__ajax_get(i, total, ppid, url);
			}, 1000)
		} else {
			image_scrubbing_assistant__filter_and_write_data(total, ppid, 'Unknown HTTP error');
		}
	}
});

}


function image_scrubbing_assistant__filter_and_write_data(total, ppid, json){
	
	$$('.page-image-scrubbing-assistant .content-block p').eq(1).html('Completed '+ ($$(".page-image-scrubbing-assistant .data-table table tbody tr").length + 1) + ' of ' + total);

	output = '';

	pp_id_or_lot_number = ppid;
	output__status = '-';
	
	output__ppid = '-';
	output__lots = '-';
	output__title = '-';
	output__copy = '-';
	output__missing_primary_image = '-';
	output__missing_swatches = '-';
	output__ccr_issues = '-';
	output__missing_brand_logo = '-';
	output__missing_ka = '-';

	if(json=='Product not found'||json=='Invalid JSON response'||json=='404 error'||json=='500 error'||json=='Unknown HTTP error'){
		output__status = json;
		output = '<tr class="error"><td>' + pp_id_or_lot_number + '</td><td>'+output__status+'</td><td>'+output__ppid+'</td><td>'+output__lots+'</td><td>'+output__missing_primary_image.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_swatches+'</td><td>'+output__ccr_issues.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_brand_logo.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_ka.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td></tr>';
	} else {
		output__status = 'Product is OK';
		
		data_array = JSON.parse(json);
		
		//PP ID
		if(data_array["productDetails"].id){
			output__ppid = data_array["productDetails"].id
		}
		
		//Lot numbers
		if(data_array["productDetails"].lots){
			output__lots_array = data_array["productDetails"].lots;
			$$.each(output__lots_array, function(i, item){
				output__lots += output__lots_array[i].id + ', ';
			})
			if(output__lots!='-'){output__lots = output__lots.substring(1, output__lots.length-2)}
		}
		
		//Title
		if(data_array["productDetails"].lots){
			//output__title = data_array["productDetails"].name
		}

		//Copy
		if(data_array["productDetails"].lots[0].description){
			//output__copy = data_array["productDetails"].lots[0].description
			//output__copy = output__copy.substring(0, 32767)
		}
		
		//Missing primary image
		output__missing_primary_image = 'No';
		if(!data_array["productDetails"].images){output__missing_primary_image = 'Yes'}

		
		//Missing color(s)
		output__missing_swatches = 'No|';
		output__ccr_issues = 'No|';
		if(data_array["productDetails"].dimensions){

			dimensions_array = data_array["productDetails"].dimensions;
			
			for(var i=0; i < dimensions_array.length; i++){

				if(dimensions_array[i].id&&dimensions_array[i].id=='COLOR'){

					if(dimensions_array[i].options){

						color_options_array = dimensions_array[i].options;
						
						for(var x=0; x < color_options_array.length; x++){
							if(!color_options_array[x].image){output__missing_swatches+=color_options_array[x]['value']+', '}
							if(color_options_array.length>1&&color_options_array[x].image&&!color_options_array[x].productImage){output__ccr_issues+=color_options_array[x]['value']+', '}
						}
					}
				}
			}
			
			if(output__missing_swatches=='No|'){output__missing_swatches='No'}else{output__missing_swatches=output__missing_swatches.substring(3, output__missing_swatches.length - 2)}
			if(output__ccr_issues=='No|'){output__ccr_issues='No'}else{output__ccr_issues=output__ccr_issues.substring(3, output__ccr_issues.length - 2)}
			
		}
		
		//Missing brand logo
		output__missing_brand_logo = 'No';
		if(!data_array["productDetails"].brand.url){output__missing_brand_logo = 'Yes'}

		//Missing KA
		output__missing_ka = 'No';
		//if( (data_array["productDetails"].knowledgeAssistants[0].id) == "undefined"){output__missing_ka = 'Yes'}
		
		try{
			output__missing_ka = data_array["productDetails"].knowledgeAssistants[0].id
			output__missing_ka = "No"
		}catch(e){
		   output__missing_ka = "Yes"
		}
		
		output = '<tr class="error"><td>' + pp_id_or_lot_number + '</td><td>'+output__status+'</td><td>'+output__ppid+'</td><td>'+output__lots+'</td><td>'+output__missing_primary_image.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_swatches.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__ccr_issues.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_brand_logo.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td><td>'+output__missing_ka.replace('No|','No').replace('Yes|','Yes').replace('[|]','')+'</td></tr>';
	}
	
	
	//console.log(ppid+' - '+output);return false;

	$$(output).prependTo(".page-image-scrubbing-assistant .data-table table tbody");

	if (($$(".page-image-scrubbing-assistant .data-table table tr").length - 1) == 1) {
			$$(".page-image-scrubbing-assistant .data-table table").show();
	}
	
	if (total == ($$(".page-image-scrubbing-assistant .data-table table tr").length - 1) ) {
		$$('.page-image-scrubbing-assistant .content-block p').eq(1).html('Scrubbing completed for '+total+' PP IDs. <span id="export_table_to_xlsx" class="color-red">Download</span> results or click <span id="reload-assistant" class="color-red">here</span> to scrub again.');
	}

}

$$(document).on("click", ".page-image-scrubbing-assistant #reload-assistant", function() {
	mainView.router.refreshPage();
})

$$(document).on("click", ".page-image-scrubbing-assistant #export_table_to_xlsx", function() {
	$$( $$('table thead tr').parent('thead').html().replace(/<th>/g, '<td>').replace(/<\/th>/g, '</td>').replace(/<tr>/g, '<tr style="display:none">') ).prependTo(".page-image-scrubbing-assistant .data-table table tbody");

	var file = {
        worksheets: [
            []
        ],
        creator: 'JCP+ Scrubbing Assistant v1.0.0',
        created: new Date('1/1/2017'),
        lastModifiedBy: 'JCP+ Scrubbing Assistant v1.0.0',
        modified: new Date(),
        activeWorksheet: 0
    }, w = file.worksheets[0];
    w.name = 'JCP+ Scrubbing Report';

	$$('table tbody tr').each(function (i, item) {
        var r = w.push([]) - 1;
        $$(this).find('td').each(function(){
			cell_value = $$(this).text();
			if(i==0){cell_value = '['+$$(this).text()+']'}
			if(cell_value != 'Yes' && cell_value.substring(0,3) == 'Yes' ){ cell_value = 'Yes ['+cell_value.substring(3, cell_value.length)+']' }
			else if(cell_value != 'No' && cell_value.substring(0,2) == 'No' ){ cell_value = 'No ['+cell_value.substring(2, cell_value.length)+']' }
			else{cell_value = cell_value;}			
            w[r].push(cell_value);
        });
    });

    window.location = xlsx(file).href();
});

