var optionsUrl = chrome.extension.getURL('jcp.plus.html');

setInterval(function(){
	chrome.tabs.query({url: optionsUrl}, function(tabs) {
		if (tabs.length) {
			if(tabs.length>1){
				for(var i = 1; i < tabs.length; i++){
					chrome.tabs.remove(tabs[i].id, function() { });
				}
				chrome.tabs.update(tabs[0].id, {pinned: true, active: false});
			} else {
				chrome.tabs.update(tabs[0].id, {pinned: true, active: false});
			}
		} else {
			chrome.tabs.create({url: optionsUrl, pinned: true, index: 0, active: false});
		}
	})
},5000)

var jcp_plus__site_audit_assistant__input = '';
var jcp_plus__site_audit_assistant__audit_tab_id_created = '';

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse){
	if(message.jcp_plus__site_audit_assistant__start){
		jcp_plus__site_audit_assistant__input = message.jcp_plus__site_audit_assistant__start
		product_id = jcp_plus__site_audit_assistant__input.split('|')[2];
		chrome.tabs.query({},function(tabs){
			for(var i = 0; i < tabs.length; i++){
				if(tabs[i].url != optionsUrl && (tabs[i].url).indexOf('https://www.maruthigowda.com') == -1 && (tabs[i].url).indexOf('chrome://') == -1 && (tabs[i].url).indexOf('lenldtmgtpr1p01.jcpenney.com:82') == -1 && (tabs[i].url).indexOf('://10.32.235.130') == -1 && (tabs[i].url).indexOf('://map.jcpenney.com') == -1 ){
					chrome.tabs.remove(tabs[i].id);
				}
			}
			chrome.tabs.create({url: 'https://www.jcpenney.com/s/' + product_id + '?Ntt=' + product_id, pinned: true, index: 1}, function(tab){
				jcp_plus__site_audit_assistant__audit_tab_id_created = tab.id
			});
		})
	}

	else if(message.jcp_plus__site_audit_assistant__stop){
		chrome.tabs.query({},function(tabs){
			for(var i = 0; i < tabs.length; i++){
				if(tabs[i].url != optionsUrl && (tabs[i].url).indexOf('https://www.maruthigowda.com') == -1 && (tabs[i].url).indexOf('chrome://') == -1 && (tabs[i].url).indexOf('lenldtmgtpr1p01.jcpenney.com:82') == -1 && (tabs[i].url).indexOf('://10.32.235.130') == -1 && (tabs[i].url).indexOf('://map.jcpenney.com') == -1 ){
					chrome.tabs.remove(tabs[i].id);
				}
			}
		})
	}

	else if(message.jcp_plus__site_audit_assistant__get_input){
		if(sender.tab.id.toString() == jcp_plus__site_audit_assistant__audit_tab_id_created){

			proceed = 0;
			product_id = jcp_plus__site_audit_assistant__input.split('|')[2];
			lots_array = jcp_plus__site_audit_assistant__input.split('|')[3].split(',');

			for(var i = 0; i < lots_array.length;i++){
				if( sender.tab.url.indexOf('?Ntt='+product_id) != -1 || sender.tab.url.indexOf('?Ntt='+lots_array[i]) != -1 || sender.tab.url.indexOf('searchTerm='+lots_array[i]) != -1 || sender.tab.url.indexOf('redirectTerm='+lots_array[i]) != -1 || sender.tab.url.indexOf('/'+product_id+'?') != -1 || sender.tab.url.indexOf('/s/'+product_id+'?') != -1 ){
					proceed = 1;
				}
			}

			if(proceed==0){return false}

			sendResponse({ jcp_plus__site_audit_assistant__input: localStorage.getItem('jcp_plus_site_audit_assistant_settings').replace(/\|/g, ',')+'|'+jcp_plus__site_audit_assistant__input})

		}
	}
	
	/*
	else if(message.jcp_plus__site_audit_assistant__next){
		alert('aaa')
		localStorage.setItem('jcp_plus__site_audit_assistant__input', jcp_plus__site_audit_assistant__input+'|next');
		chrome.tabs.remove(sender.tab.id);
		chrome.tabs.query({url: optionsUrl}, function(tabs){
			chrome.tabs.update(tabs[0].id, {pinned: true, active: true});
		})
	}
	*/

})


chrome.runtime.onMessageExternal.addListener(function(message, sender, sendResponse){
	if(message.jcp_plus__site_audit_assistant__next){
		localStorage.setItem('jcp_plus__site_audit_assistant__input', jcp_plus__site_audit_assistant__input+'|next');
		chrome.tabs.remove(sender.tab.id);
		chrome.tabs.query({url: optionsUrl}, function(tabs){
			chrome.tabs.update(tabs[0].id, {pinned: true, active: true});
		})
	}
});

