//css styles
var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
if (isChrome) {document.write('<style>::-webkit-scrollbar{display:none}html{background: #444;height:100%;overflow:hidden;}body{border:8px solid #d71920;margin: 23px auto!important; max-width: 500px; max-height: 92%; box-shadow: 0 0 34px #000;background-image:url("chrome/framework7/img/splash-screen.png")!important;background-repeat:no-repeat!important;background-position:center,center!important;}.views{opacity:0}.picker-keypad-button:before{background-color:#fff!important;border-bottom: 1px solid rgba(92,94,96,.35);}.html-dynamic-page-site-audit-assistant-new-allotment .floating-button,.html-dynamic-page-site-audit-assistant-backlog .floating-button{visibility:visible!important;}.form-radio i:after, label.label-radio i.icon-form-radio:after{left:52%!important;top:49%!important;}</style>');}

//splash-screen
var splashScreenStatus=1;
function Chrome__splashScreenCHK(){if(splashScreenStatus==1){document.querySelector('.views').style.opacity='0'}else{document.querySelector('.views').style.opacity='1';clearInterval(Chrome__splashScreenCHKInterval)}}
var Chrome__splashScreenCHKInterval=setInterval(function(){Chrome__splashScreenCHK()},1000)

//Notifications module
chrome.notifications.onClosed.addListener(function(notifId) {
	//alert('closed: '+notifId)
});

chrome.notifications.onButtonClicked.addListener(function(notifId, btnIdx) {
	    if (notifId=="jcp_plus_chrome_notification_id") {
        if (btnIdx == 0) {
            chromeDeepLinkShowNotificationDetails()
			chrome.notifications.clear(notifId)
        } else if (btnIdx == 1) {
			chrome.notifications.clear(notifId)
        }
    }
});





function chromeDeepLinkShowNotificationDetails(){

var optionsUrl = chrome.extension.getURL('jcp.plus.html');

chrome.tabs.query({url: optionsUrl}, function(tabs) {
    if (tabs.length) {
        chrome.tabs.update(tabs[0].id, {active: true});
    } else {
        chrome.tabs.create({url: optionsUrl});
    }
	generateDynamicPageForNotifications();
});

}
